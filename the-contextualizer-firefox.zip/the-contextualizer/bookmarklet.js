javascript:(function(){
/*
THE CONTEXTUALIZER -- bookmarklet.js -- v125

v125 change: added the same remote kill-switch / domain blocklist as content.js v125 -- fetches
a small hosted list (GitHub Gist raw URL, evergreen) at the start of every run and stands down
on any listed domain. Fails open on any error (network failure, 404, timeout) -- runs normally
exactly as if this feature didn't exist. Unlike the extension, the bookmarklet isn't sideloaded
in the same persistent sense (it's re-triggered manually per page), but this still means an
already-copied bookmarklet respects the blocklist without the user needing a fresh copy.

Ported from content.js v120-v123 (this file previously had none of these fixes; it is a
separate, simplified implementation, not a copy of content.js, so each fix was re-applied
by hand against this file's own structure):

1. isTitleCaseWithContext (v120): isTitleCase() alone returns false whenever a text node has
   fewer than 2 qualifying words, which happens when a name is isolated in its own DOM text
   node. Added an ancestor-walking fallback so isolated names still pick up Title Case
   correctly from their surrounding heading/paragraph context.

2. SPA navigation reset (v121): subjectState.introduced never reset within a single-page-app
   session (e.g. browsing multiple emails in one Gmail tab without a full reload). Added
   pushState/replaceState/hashchange/popstate detection that resets introduced-state on URL
   change, so each new message/article starts fresh.

3. Node-identity + content-based re-arm (v122+v123): a correct "first mention" could get
   silently overwritten by an incorrect "subsequent mention" moments later, when a site resets
   a node's text back to original (same node object) or remounts a whole block with fresh node
   objects containing the same original text. Now tracks both the introducing node
   (introducerNode) and its original text (introducerText), and re-arms as a fresh first
   mention if either matches on reprocessing.

Prerequisite infrastructure added for fix 3 to have anything to act on: this file's
MutationObserver previously only watched childList mutations, so an in-place text reset (site
resets a node's .nodeValue directly, no new nodes added/removed) was never caught at all -- the
edit would just silently vanish with nothing reprocessing it. Now also observes characterData
mutations and reprocesses the affected node when they fire.
*/
const SUBJECTS = [
{
patterns: [
/\b(President\s+Trump|Donald\s+Trump|Trump)([\u2019']s)?/g
],
compounds: {
'Administration': 'Evil',
'Family': 'Corrupt',
'Organization': null,
'Tower': null,
'Hotel': null,
'Resort': null,
'Golf': null,
'Foundation': null,
'Empire': null,
},
modifiers: [
"stupid fuckhead", "shithead", "shit for brains", "convicted felon",
"convicted sex offender", "sexual predator", "cad", "suspected rapist",
"failed businessman", "failed real estate mogul", "racist", "white supremacist",
"proud boy", "Aspiring Grand Dragon", "pathological liar", "worst human",
"poor excuse of a human", "sad sack", "tiny handed", "fuckface",
"war criminal", "water sports enthusiast", "moron", "dipshit-in-Chief",
"cretin", "public servant", "oaf", "democratically elected", "disaster of a human",
"orange stain", "complete asshole", "bigot", "trust fund baby", "hideous man",
"habitual golfer", "cheat", "life enigma", "idiot", "loser", "bully",
"sociopath", "bitch-ass", "freak", "mean man", "big dummy",
"pig fucker", "asshole", "malformed", "disgraced", "supreme jerk",
"know-nothing", "magnificent dickhead", "Jeffrey Epstein confidant",
"shyster", "career con man", "enemy of all things good", "dumbfuck",
"shell of a man", "punk-bitch", "asshat", "Combover King",
"Muppet", "strongman puppet", "oligarch", "donut", "dishonorable",
"reality television personality", "tasteless", "clown IRL", "conniving",
"uncouth", "dumbass", "doofus", "walking tumor",
"autocrat", "dictator", "kleptocrat", "corrupt", "rube", "fool",
"fraud", "bullshit artist", "disaster artist", "C-lister", "phony",
"thief", "despot", "American oligarch"
],
properModifiers: new Set([
"Aspiring Grand Dragon",
"Jeffrey Epstein confidant",
"Combover King",
"Muppet",
"American oligarch"
]),
},
{
patterns: [
/\b(Vice\s+President\s+(?:J\.?D\.?\s+Vance|Vance)|J\.?D\.?\s+Vance|Vance)([\u2019']s)?/g
],
compounds: {},
modifiers: ["lap dog"],
properModifiers: new Set(),
useInnerHTML: true,
},
];
const titleCaseSmallWords = new Set([
"a", "an", "the", "and", "but", "or", "for", "nor", "on", "at",
"to", "by", "in", "of", "up", "as", "is", "it", "its"
]);
const recentHistory = new Map();
const HISTORY_BUFFER = 5;
function getRandom(arr) {
if (arr.length <= 1) return arr[0];
if (!recentHistory.has(arr)) recentHistory.set(arr, []);
const recent = recentHistory.get(arr);
const available = arr.filter(m => !recent.includes(m));
const pick = available.length > 0
? available[Math.floor(Math.random() * available.length)]
: arr[Math.floor(Math.random() * arr.length)];
recent.push(pick);
if (recent.length > HISTORY_BUFFER) recent.shift();
return pick;
}
function isStartOfSentence(text, matchIndex) {
if (matchIndex === 0) return true;
const before = text.slice(0, matchIndex);
const trimmed = before.trimEnd();
if (trimmed.length === 0) return true;
return /[.!?]$/.test(trimmed);
}
function isTitleCase(text) {
const words = text.match(/\b[a-zA-Z]{4,}\b/g);
if (!words || words.length < 2) return false;
const capitalizedCount = words.filter(w => /^[A-Z]/.test(w)).length;
const ratio = capitalizedCount / words.length;
const isShort = text.trim().split(/\s+/).length <= 15;
return ratio >= (isShort ? 0.45 : 0.6);
}
function isTitleCaseWithContext(text, node) {
if (isTitleCase(text)) return true;
let el = node && node.parentElement;
for (let i = 0; i < 4; i++) {
if (!el) break;
const tag = (el.tagName || '').toLowerCase();
if (['h1','h2','h3','h4','h5','h6'].includes(tag)) return true;
if (isTitleCase(el.textContent || '')) return true;
el = el.parentElement;
}
return false;
}
function toTitleCase(str, isHeadline) {
return str.split(' ').map((word, index) => {
if (index !== 0 && titleCaseSmallWords.has(word.toLowerCase())) {
return word.toLowerCase();
}
if (word.includes('-')) {
const parts = word.split('-');
if (isHeadline) {
return parts.map((part, i) => {
if (i > 0 && i < parts.length - 1 && titleCaseSmallWords.has(part.toLowerCase())) {
return part.toLowerCase();
}
return part.charAt(0).toUpperCase() + part.slice(1).toLowerCase();
}).join('-');
}
return parts.map((part, i) => {
if (i === 0) return part.charAt(0).toUpperCase() + part.slice(1).toLowerCase();
if (part.toLowerCase() === 'chief') return 'Chief';
return part.toLowerCase();
}).join('-');
}
return word.charAt(0).toUpperCase() + word.slice(1);
}).join(' ');
}
function isInNavigation(node) {
let el = node.parentElement;
while (el) {
const tag = el.tagName ? el.tagName.toLowerCase() : '';
const role = (el.getAttribute && el.getAttribute('role') || '').toLowerCase();
const cls = (el.className && typeof el.className === 'string') ? el.className.toLowerCase() : '';
if (
tag === 'nav' ||
tag === 'header' ||
role === 'navigation' ||
role === 'menubar' ||
role === 'menu' ||
cls.includes('nav') ||
cls.includes('menu') ||
cls.includes('sidebar') ||
cls.includes('breadcrumb')
) return true;
el = el.parentElement;
}
return false;
}
const subjectState = SUBJECTS.map(() => ({ introduced: false, introducerNode: null, introducerText: null }));
const modifierCache = new Map();
function buildModifyFn(subject, state) {
const { modifiers, properModifiers, compounds } = subject;
const compoundNames = Object.keys(compounds).filter(k => compounds[k] !== null);
const compoundPattern = compoundNames.length
? new RegExp(`([Tt]he\\s+)?\\b(${subject.patterns[0].source.replace(/\(.*?\)/g, (m) => m)})([\u2019']s)?(\\s+(${compoundNames.join('|')})\\b)?`, 'g')
: null;
return function modifyText(text, node) {
// Prefer ancestor-aware detection (isTitleCaseWithContext) so an isolated node (e.g. a name
// alone in its own text node inside a Title Case headline) doesn't get misjudged.
const titleCase = isTitleCaseWithContext(text, node);
// If this exact text node (or, failing that, this exact original text) previously introduced
// the subject but is showing up again unmodified, treat it as the first mention again rather
// than a subsequent one. Covers both a site resetting a node's content in place (same node
// object) and a whole-block remount that mounts a brand new node with identical original text.
if (node && (state.introducerNode === node || (state.introducerText !== undefined && text === state.introducerText))) {
state.introduced = false;
}
const compoundList = Object.keys(compounds);
const namePattern = subject.patterns[0];
const fullPattern = new RegExp(
`([Tt]he\\s+)?` +
namePattern.source.replace(/\/g$/, '') +
`(\\s+(${compoundList.join('|')})\\b)?`,
'g'
);
return text.replace(fullPattern, (fullMatch, thePrefix, name, possessive, compoundSuffix, compoundNoun, offset) => {
const sentenceStart = isStartOfSentence(text, offset);
const isVanceAlone = name === 'Vance' && text.trim() === 'Vance';
const isVanceAtEnd = name === 'Vance' && /Vance$/.test(text.trim());
const trailingSpace = (isVanceAlone || isVanceAtEnd) ? ' ' : '';
if (compoundNoun && compoundNoun in compounds) {
const fixedModifier = compounds[compoundNoun];
if (!fixedModifier) return fullMatch;
const cap = titleCase ? fixedModifier.charAt(0).toUpperCase() + fixedModifier.slice(1) : fixedModifier.toLowerCase();
const the = thePrefix ? thePrefix : (titleCase ? 'The ' : 'the ');
return `${the}${cap} ${name}${possessive || ''}${compoundSuffix}`;
}
const modifier = getRandom(modifiers);
const isProper = properModifiers.has(modifier);
if (titleCase) {
const displayModifier = isProper ? toTitleCase(modifier, true) : toTitleCase(modifier, true);
const article = sentenceStart ? 'The' : 'the';
if (isProper) return `${toTitleCase(modifier, true)} ${name}${possessive || ''}${trailingSpace || ''}`;
return `${article} ${displayModifier} ${name}${possessive || ''}${trailingSpace || ''}`;
}
if (state.introduced) {
const article = sentenceStart ? 'The' : 'the';
if (isProper) return `${modifier}${possessive || ''}${trailingSpace || ''}`;
return `${article} ${modifier}${possessive || ''}${trailingSpace || ''}`;
}
state.introduced = true;
state.introducerNode = node || null;
state.introducerText = text;
const afterMatch = text.slice(offset + fullMatch.length).trim();
const isAtEnd = afterMatch.length === 0 || /^[.!?,;]/.test(afterMatch);
const forceBefore = !!possessive || isAtEnd;
const before = forceBefore || Math.random() < 0.75;
const displayModifier = isProper ? modifier : modifier;
const article = sentenceStart ? 'The' : 'the';
if (before) {
if (isProper) return `${modifier} ${name}${possessive || ''}${trailingSpace || ''}`;
return `${article} ${displayModifier} ${name}${possessive || ''}${trailingSpace || ''}`;
} else {
return `${name}, the ${modifier},${trailingSpace || ''}`;
}
});
};
}
const subjectModifyFns = SUBJECTS.map((subject, i) => buildModifyFn(subject, subjectState[i]));
function processTextForSubject(text, subjectIndex, node) {
return subjectModifyFns[subjectIndex](text, node);
}
function alreadyModified(text) {
return SUBJECTS.some(subject => {
return Object.entries(subject.compounds).some(([noun, modifier]) => {
if (!modifier) return false;
const escaped = modifier.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
return new RegExp(`\\b${escaped}\\s+(President\\s+)?Trump\\s+${noun}\\b`, 'i').test(text);
});
});
}
const processedElements = new WeakSet();
function processElementHTML(element) {
if (processedElements.has(element)) return;
const plainText = element.textContent || '';
if (!/\bVance\b/.test(plainText)) return;
if (/Lap Dog/.test(plainText)) return;
processedElements.add(element);
const directText = Array.from(element.childNodes)
.filter(n => n.nodeType === Node.TEXT_NODE)
.map(n => n.nodeValue.trim())
.join('').trim();
if (directText.length < 30 || /^(JD\s+Vance|J\.D\.\s+Vance|Vice\s+President\s+Vance)$/i.test(directText)) return;
const trimmed = plainText.trim();
if (trimmed.length < 30) return;
let titleCase = isTitleCase(plainText);
if (!titleCase) {
let el = element;
for (let i = 0; i < 4; i++) {
if (!el) break;
const t = (el.tagName || '').toLowerCase();
if (['h1','h2','h3','h4','h5','h6'].includes(t)) { titleCase = true; break; }
if (t === 'p' && isTitleCase(el.textContent || '')) { titleCase = true; break; }
el = el.parentElement;
}
}
SUBJECTS.forEach((subject, i) => {
if (!subject.useInnerHTML) return;
const state = subjectState[i];
const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, null);
const textNodes = [];
let n;
while ((n = walker.nextNode())) textNodes.push(n);
textNodes.forEach(node => {
const orig = node.nodeValue;
if (!/\bVance\b/.test(orig)) return;
const modified = orig.replace(
/\b(Vice\s+President\s+(?:J\.?D\.?\s*Vance|Vance)|J\.?D\.?\s*Vance|Vance)([\u2019\']s)?/g,
(fullMatch, name, possessive, offset) => {
const sentenceStart = isStartOfSentence(orig, offset);
const article = (sentenceStart || titleCase) ? 'The' : 'the';
const art = sentenceStart ? 'The' : 'the';
if (state.introduced) {
return art + ' Lap Dog ' + name + (possessive || '');
}
state.introduced = true;
return art + ' Lap Dog ' + name + (possessive || '');
}
);
if (modified !== orig) {
node.nodeValue = modified;
}
});
});
}
function processTextNode(node) {
let text = node.nodeValue;
let modified = false;
if (alreadyModified(text)) return;
SUBJECTS.forEach((subject, i) => {
if (subject.useInnerHTML) return;
const pattern = new RegExp(subject.patterns[0].source, 'g');
if (!pattern.test(text)) return;
const newText = processTextForSubject(text, i, node);
if (newText !== text) {
text = newText;
modified = true;
}
});
if (modified) node.nodeValue = text;
}
function processCompoundNode(node) {
let text = node.nodeValue;
let modified = false;
SUBJECTS.forEach((subject) => {
const compoundNames = Object.keys(subject.compounds).filter(k => subject.compounds[k] !== null);
if (!compoundNames.length) return;
const pattern = new RegExp(
`([Tt]he\\s+)?\\b(President\\s+Trump|Trump)([\\u2019']s)?(\\s+(${compoundNames.join('|')})\\b)`,
'g'
);
const titleCase = isTitleCaseWithContext(text, node);
const newText = text.replace(pattern, (fullMatch, thePrefix, name, possessive, compoundSuffix, compoundNoun) => {
const fixedModifier = subject.compounds[compoundNoun];
if (!fixedModifier) return fullMatch;
const cap = titleCase
? fixedModifier.charAt(0).toUpperCase() + fixedModifier.slice(1)
: fixedModifier.toLowerCase();
const the = thePrefix ? thePrefix : (titleCase ? 'The ' : 'the ');
return `${the}${cap} ${name}${possessive || ''}${compoundSuffix}`;
});
if (newText !== text) { text = newText; modified = true; }
});
if (modified) { node.nodeValue = text; return; }
if (!/Trump/.test(text)) return;
const next = node.nextSibling;
if (!next || next.nodeType !== Node.TEXT_NODE) return;
const combined = text + next.nodeValue;
SUBJECTS.forEach((subject) => {
const compoundNames = Object.keys(subject.compounds).filter(k => subject.compounds[k] !== null);
if (!compoundNames.length) return;
const pattern = new RegExp(
`([Tt]he\\s+)?\\b(President\\s+Trump|Trump)([\\u2019']s)?(\\s+(${compoundNames.join('|')})\\b)`,
'g'
);
if (!pattern.test(combined)) return;
const titleCase = isTitleCaseWithContext(combined, node);
const newCombined = combined.replace(pattern, (fullMatch, thePrefix, name, possessive, compoundSuffix, compoundNoun) => {
const fixedModifier = subject.compounds[compoundNoun];
if (!fixedModifier) return fullMatch;
const cap = titleCase
? fixedModifier.charAt(0).toUpperCase() + fixedModifier.slice(1)
: fixedModifier.toLowerCase();
const the = thePrefix ? thePrefix : (titleCase ? 'The ' : 'the ');
return `${the}${cap} ${name}${possessive || ''}${compoundSuffix}`;
});
if (newCombined !== combined) {
node.nodeValue = newCombined;
next.nodeValue = '';
}
});
}
function walkTextNodes(root, compoundOnly) {
const walker = document.createTreeWalker(
root,
NodeFilter.SHOW_TEXT,
{
acceptNode(node) {
const parent = node.parentElement;
if (!parent) return NodeFilter.FILTER_REJECT;
const tag = parent.tagName;
if (["SCRIPT", "STYLE", "NOSCRIPT", "TEXTAREA"].includes(tag)) return NodeFilter.FILTER_REJECT;
if (!compoundOnly && isInNavigation(node)) return NodeFilter.FILTER_REJECT;
return NodeFilter.FILTER_ACCEPT;
}
}
);
const nodes = [];
let node;
while ((node = walker.nextNode())) nodes.push(node);
nodes.forEach(compoundOnly ? processCompoundNode : processTextNode);
}
function walkElementsForHTML(root) {
const hasInnerHTML = SUBJECTS.some(s => s.useInnerHTML);
if (!hasInnerHTML) return;
const walker = document.createTreeWalker(
root,
NodeFilter.SHOW_ELEMENT,
{
acceptNode(node) {
const tag = node.tagName ? node.tagName.toLowerCase() : '';
if (["script", "style", "noscript", "textarea"].includes(tag)) return NodeFilter.FILTER_REJECT;
const role = (node.getAttribute && node.getAttribute('role') || '').toLowerCase();
if (tag === 'nav' || role === 'navigation' || role === 'menubar') return NodeFilter.FILTER_REJECT;
if (["h1","h2","h3","h4","h5","h6","p","a","li","span","div"].includes(tag)) {
return NodeFilter.FILTER_ACCEPT;
}
return NodeFilter.FILTER_SKIP;
}
}
);
const elements = [];
let el;
while ((el = walker.nextNode())) elements.push(el);
elements.forEach(processElementHTML);
}
const CTX_BLOCKLIST_URL = 'https://gist.githubusercontent.com/Mch7777/b7aa683412ee50d31441bdccfd67b658/raw/gistfile1.txt';
const CTX_BLOCKLIST_TIMEOUT_MS = 1200;
function ctxHostIsBlocked(list) {
const host = location.hostname.replace(/^www\./, '').toLowerCase();
return list.some(entry => {
const e = entry.trim().toLowerCase();
if (!e || e.startsWith('#')) return false;
return host === e || host.endsWith('.' + e);
});
}
function ctxFetchBlocklist() {
return new Promise((resolve) => {
let settled = false;
const settle = (list) => { if (!settled) { settled = true; resolve(list); } };
setTimeout(() => settle([]), CTX_BLOCKLIST_TIMEOUT_MS);
fetch(CTX_BLOCKLIST_URL, { cache: 'no-store' })
.then(r => (r.ok ? r.text() : ''))
.then(text => settle(text.split('\n').filter(Boolean)))
.catch(() => settle([]));
});
}
function ctxInit() {
walkTextNodes(document.body, true);
walkTextNodes(document.body, false);
walkElementsForHTML(document.body);
function resetIntroducedState() {
subjectState.forEach(s => { s.introduced = false; });
}
let lastCtxUrl = location.href;
function checkCtxUrlChange() {
if (location.href !== lastCtxUrl) {
lastCtxUrl = location.href;
resetIntroducedState();
}
}
['pushState', 'replaceState'].forEach(fnName => {
const orig = history[fnName];
history[fnName] = function (...args) {
const result = orig.apply(this, args);
checkCtxUrlChange();
return result;
};
});
window.addEventListener('popstate', checkCtxUrlChange);
window.addEventListener('hashchange', checkCtxUrlChange);
const observer = new MutationObserver((mutations) => {
for (const mutation of mutations) {
if (mutation.type === 'characterData') {
const node = mutation.target;
processCompoundNode(node);
processTextNode(node);
continue;
}
for (const added of mutation.addedNodes) {
if (added.nodeType === Node.TEXT_NODE) {
processCompoundNode(added);
processTextNode(added);
} else if (added.nodeType === Node.ELEMENT_NODE) {
walkTextNodes(added, true);
walkTextNodes(added, false);
walkElementsForHTML(added);
}
}
}
});
observer.observe(document.body, { childList: true, subtree: true, characterData: true });
}
ctxFetchBlocklist().then((list) => {
if (ctxHostIsBlocked(list)) { return; }
ctxInit();
});
})();