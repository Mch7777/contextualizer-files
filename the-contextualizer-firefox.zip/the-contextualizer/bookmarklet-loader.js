javascript:(function(){
  var s=document.createElement('script');
  s.src='https://YOUR-HOSTING-URL/contextualizer.js?v='+Date.now();
  document.head.appendChild(s);
})();
