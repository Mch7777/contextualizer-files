// =============================================================================
// THE CONTEXTUALIZER — content.js
// v146
//
// Changes from v145:
//   - Fixed non-headline (dek/body-text) mentions incorrectly getting full Title Case styling on
//     multi-word insertions -- confirmed via a real example: "The Tasteless World Leader is the
//     47th president..." (a dek), where "World Leader" got both words capitalized even though
//     the dek's own surrounding sentence was plainly normal sentence-case prose the whole time.
//     Invisible with single-word modifiers (capitalize-the-whole-word and
//     capitalize-just-the-first-letter look identical for one word), only visible once a
//     two-word companion noun made the difference visible. Root cause: titleCase is computed
//     partly from "is this wrapped in an h1-h6 tag", which is true for a dek by definition (the
//     same tag that needed all the dek-detection work), conflating "should this mention keep the
//     name" with "is this text actually Title-Case styled" -- a dek usually isn't, same as the
//     rest of a news source's body copy. Tightening that check alone wouldn't have been enough
//     either: confirmed the sentence's own ratio-based check independently misfires here too,
//     since a short sentence containing a two-word proper noun ("United States") pushes the
//     capitalized-word ratio over threshold on its own. Fixed by removing the titleCase
//     dependency entirely from the two non-headline branches (subsequent-mention and
//     first-body-mention) -- sentence-start capitalization there was already handled correctly
//     by the "The"/"the" article or capitalizeFirst for proper modifiers, so the modifier/noun
//     never actually needed the title-case guess layered on top. Headline styling (Fox-vs-NYT
//     sentence-case-vs-title-case distinction) is completely untouched -- this only affects the
//     two branches that were already known to represent normal prose, not headlines. Verified:
//     exact match to the requested output, headline branch confirmed unaffected, proper
//     modifiers confirmed still correctly sentence-cased, and acronym preservation (US) confirmed
//     still working.
//
// Changes from v144 (content/copy edits, no logic changes):
//   - Added "gammon" and "knob" (British slang) to the modifier pool -- regular modifiers, keep
//     the article.
//
// Changes from v143 (content/copy edits, no logic changes):
//   - Added "wanker" and "tosser" (British slang) to the modifier pool -- regular modifiers,
//     keep the article, same bucket as "asshole" or "moron".
//
// Changes from v142:
//   - Restored a 75/25 modifier-placement rule established early in the project that content.js
//     itself never actually implemented -- confirmed via a "JD Vance" topic-listing screenshot
//     showing every single mention modifier-first ("The Lap Dog Vance"), never the appositive
//     form ("Vance, the lap dog,"). Only bookmarklet.js's separate, older codebase had this
//     logic; content.js's first-body-mention branch always placed the modifier before the name,
//     unconditionally. Ported the logic over, fixing two gaps in bookmarklet.js's original
//     version along the way: it hardcoded lowercase "the" in the after-branch regardless of
//     titleCase/sentenceStart, and never checked isProper there at all, which would have
//     incorrectly given proper modifiers like "Fat Shady" an article in that branch. Forced to
//     "before" placement when there's a possessive or the match sits at/near the end of the
//     sentence (no room for a trailing appositive). Verified: 75.0/25.0 exact split across 200
//     trials, 0% after-placement when forced conditions apply, proper modifiers correctly skip
//     the article in both placements, and the headline branch (unaffected by this change)
//     confirmed still always modifier-first.
//
// Changes from v141:
//   - Fixed modifier repeats within a single page view (confirmed: "Oligarch" used twice on one
//     NYT topic-page screenshot -- main headline and a story teaser further down). The
//     repeat-avoidance mechanism already existed (getRandom's recentHistory buffer) but
//     HISTORY_BUFFER was only 5 -- far too small for a busy page that can easily have 7+
//     independent headline-level mentions; an early pick ages out of the 5-slot window before
//     the page finishes rendering. Bumped to 40 (pool is 108 words), comfortably covering any
//     realistically busy single page. Also clears recentHistory on SPA navigation (alongside the
//     existing introduced-state reset), so a genuinely new "view" -- a new email, a new
//     client-side-routed article -- gets its own fresh sense of what's already been used, rather
//     than inheriting exhaustion from whatever page was open before it in the same tab.
//     recentHistory is keyed by array reference, so one .clear() covers the main modifier pool,
//     every compound's own modifier pool, and adjectiveNouns all at once. Verified: 20
//     consecutive independent headline picks (well beyond any single real page's realistic
//     count) produced zero repeats.
//
// Changes from v140 (content/copy edits, no logic changes):
//   - Added "cis male" and "vato loco" to the modifier pool (regular modifiers, keep the
//     article -- both read as descriptive noun phrases, not nickname-style). Note: "uncouth"
//     was also requested but is already in the pool (added earlier, part of the v139
//     adjective-noun pairing fix) -- not re-added.
//
// Changes from v139:
//   - Found the actual root cause of the intermittent dek bug that survived v137's fix. Debug
//     log showed the dek being correctly suppressed on initial load and once on reprocessing --
//     but a later pass showed BOTH the h1 and the dek reprocessed together with a brand new
//     random modifier on the h1, both hardcoded to isHeadline:true. That's React remounting the
//     whole header block as fresh DOM nodes, caught by the MutationObserver's childList handler
//     -- which had its own separate "new heading found" code path that never had any
//     dek-detection logic at all (`newHeadings.forEach(h => walkTextNodes(h, false, true))`,
//     unconditional). The v126-v137 dek-detection work only ever ran in the one-time initial
//     page-load pass, so it had nothing to do with what this second path did.
//   - Extracted the dek-detection logic (ctxLastH1 tracking, collection-teaser exemption,
//     order/ancestor signals) into a shared ctxProcessHeadings() function, called by both the
//     initial pass and the MutationObserver's newHeadings handling. Made ctxLastH1 and
//     ctxSeenNonH1SinceLastH1 persistent across calls (not reset per-batch) so a remount that
//     only touches the dek (h1 untouched) can still fall back on the ancestor-proximity signal
//     against the h1 already on record, not just the order signal. Also fixed the newHeadings
//     selector itself, which was missing the collection/topic-page clause the initial pass's
//     selector already had. Verified against a reconstruction of the exact remount scenario from
//     the debug log (two sequential batches, second batch simulating brand-new post-remount
//     nodes with a different random modifier): dek correctly suppressed both times, using the
//     same shared, persistent state.
//
// Changes from v138:
//   - Fixed a real grammar gap: 11 modifiers are pure adjectives with no noun (shifty, corrupt,
//     devious, disgraced, dishonorable, tasteless, conniving, uncouth, malformed, bi-curious,
//     bitch-ass). They read fine paired with the name ("the shifty Trump"), but broke as a
//     standalone subject once the name drops in a subsequent mention ("the shifty is the 47th
//     president..." -- missing a noun). Added adjectiveModifiers (the 11 affected words) and a
//     companion adjectiveNouns pool (President, US Leader, World Leader, Head of State, Tool),
//     randomly paired at render time -- but only in the subsequent-mention branch, since
//     headlines/first mentions already work fine with the name attached directly. Verified: real
//     variety across all 5 nouns, correct Title Case handling including "Head of State" (the
//     "of" staying lowercase per the existing small-words rule), "US" correctly preserved as an
//     acronym rather than lowercased to "us" in non-title-case contexts, headlines/first
//     mentions confirmed unchanged, non-adjective modifiers confirmed unaffected, and possessive
//     forms working correctly.
//
// Changes from v137 (content/copy edits, no logic changes):
//   - Reclassified has-been, know-nothing, C-lister, and Muppet into properModifiers (no
//     article) -- the underlying distinction settled on: descriptive phrases ("walking tumor,"
//     "loser") need "the" to read as English, since they're common nouns; nickname-style
//     phrases ("Shit-for-Brains," these four) function as name-replacements by design and never
//     take an article, in any position, same as real political nicknames ("Crooked Hillary,"
//     "Sleepy Joe"). This replaces an earlier, more complicated idea about the article depending
//     on sentence position -- it doesn't; it depends on what kind of phrase the modifier is.
//   - Added "Kakistocracy Premier" (an unofficial-title-style phrase, also properModifiers -- no
//     article), "gold digger" and "freeloader" (regular modifiers -- keep the article, same as
//     other descriptive phrases).
//
// Changes from v136:
//   - Found the real cause of the persisting dek bug (the v131 order/ancestor-based
//     dek-detection fix never actually had a chance to run for this case). Root cause,
//     confirmed via debug log: on NYT's Trump topic/tag page, data-testid="main-collection"
//     wraps the ENTIRE main content area -- including the page's own h1 and its dek, sitting in
//     a <header> above the actual story list -- not just the list of story teasers itself. The
//     v129 collection-teaser exemption (added so genuinely separate teasers don't get
//     incorrectly suppressed) checked only "is this inside a main-collection section", which is
//     too broad: it caught the dek too, exempting it from dek-detection entirely regardless of
//     what v131 added afterward. Narrowed the check to also require being inside a real <li>,
//     matching the exact specificity of the selector that finds these teasers in the first
//     place ('[data-testid="main-collection"] li p:first-child'). Verified against a
//     reconstruction of the real page structure (h1 + dek in a <header>, real teasers in
//     <ol><li>, all inside the same main-collection section): dek now correctly suppressed,
//     both real teasers still correctly kept.
//
// Changes from v135:
//   - Added a new modifier category: soloModifiers. properModifiers still attach the name on
//     first mention/headline (just without an article) -- but "Fat Shady" needed something
//     stronger, since it's a riff on Eminem's "Slim Shady" alter-ego and only works standing
//     completely alone. Nobody says "The Slim Shady", and "Fat Shady Donald Trump" breaks the
//     reference structurally, not just stylistically. Solo modifiers now render exactly as
//     stored, with no article and no name, in every context (headline, first mention,
//     subsequent) -- still correctly mark the subject as introduced, so later ordinary
//     modifiers elsewhere on the page still drop the name normally. Moved "Fat Shady" into this
//     new set (also capitalized in the modifiers array to match its always-standalone
//     rendering). Verified across headline, subsequent-mention, first-body-mention, and
//     possessive forms.
//
// Changes from v134 (content/copy edits, no logic changes):
//   - Moved "shit-for-brains" into properModifiers (no article, e.g. "Shit-for-Brains is the
//     47th president..." instead of "the shit-for-brains Trump").
//   - Added a narrow "brains" special case in toTitleCase()'s hyphenation logic, mirroring the
//     existing "chief" exception built for dipshit-in-Chief, so "shit-for-brains" renders fully
//     capitalized ("Shit-for-Brains") in Title Case contexts outside literal headlines (e.g. a
//     dek). Deliberately scoped narrowly to this one word rather than changing the general
//     non-headline hyphenation rule, which would have silently re-capitalized 8 other
//     hyphenated modifiers (Has-Been, C-Lister, etc.) that weren't asked about — verified via
//     direct comparison that all 8 render identically to before.
//
// Changes from v133:
//   - Refined golf/hotel property matching after testing against real phrasing turned up two
//     issues: (1) false positive — "Trump's golf game was interrupted" incorrectly got the
//     property-style modifier treatment (Garish/Gaudy/Chintzy), even though it's personal
//     activity, not a specific branded property; (2) false negative — "Trump National Golf
//     Club", his single most common real golf-property naming pattern, didn't match the Golf
//     compound at all, since "National" sits between "Trump" and "Golf", breaking the required
//     immediate adjacency, and fell through to a random unrelated modifier instead. Replaced the
//     bare "Golf" compound key with specific multi-word property names instead (Golf Club, Golf
//     Course, Golf Resort, National Golf Club, International Golf Club, National Golf Course) --
//     verified the regex alternation mechanism handles multi-word keys correctly (confirmed via
//     direct regex capture-group testing before implementing). Also added "International Hotel"
//     alongside the existing bare "Hotel" for the same real-world naming pattern. Verified end
//     to end: both original issues fixed, other real naming patterns (Golf Course, International
//     Golf Club, International Hotel) work correctly, everything previously working (Tower,
//     Organization, Administration) unaffected, and no double-modification on reprocessing.
//     NOTE: the remaining "is 'Trump National Golf Club' being discussed as a place or as a
//     business entity" ambiguity is a genuine, permanent limitation of text-pattern matching --
//     that distinction requires understanding what a sentence is actually about, not just which
//     words appear, and isn't something further regex refinement can resolve.
//
// Changes from v132 (content/copy edits, no logic changes):
//   - Activated Organization (previously null): Evil, Corrupt, Criminal, Sketchy, Rotten.
//   - Activated Tower, Hotel, Resort, and Golf (previously null, all four): Garish, Gaudy,
//     Chintzy. Note "Golf" already covers "Trump Golf Course" phrasing -- the compound match
//     only needs the single word immediately after "Trump", so "Course" rides along untouched
//     as ordinary trailing text; no separate "Golf Course" key needed.
//
// Changes from v131 (content/copy edits, no logic changes):
//   - Administration pool: replaced "Illegitimate" with "Failed".
//   - Family pool: removed "Nepotistic" (no replacement).
//   - Foundation pool: replaced "Defunct" with "Shifty".
//
// Changes from v130:
//   - Hardened dek-detection after v126's ancestor-depth-only approach (4 levels) missed a real
//     case: a dek nested deeper than 4 levels from its own h1 still incorrectly kept the name.
//     Investigation (via synthetic tests reconstructing realistic DOM depth) found the
//     ancestor-depth approach is fundamentally fragile at any threshold: walking up enough
//     levels to catch a genuinely deep dek will also, for unrelated elements, occasionally reach
//     all the way up to <body> -- which trivially "contains" everything on the page, causing
//     false positives on completely unrelated headlines elsewhere. Replaced ancestor-depth as
//     the primary signal with a depth-independent one instead: is this the very first non-h1
//     heading encountered since the last h1, with nothing else matched in between. Kept a
//     tightened ancestor check (3 levels, down from 4) as a supplementary tie-breaker only.
//     Fixing this surfaced one more wrinkle: collection/topic-page teasers (the v129 fix) are
//     also technically "the first heading after the h1" on a page like NYT's Trump topic
//     listing, but are a different category entirely (always independent stories, never a dek)
//     -- explicitly exempted via the same data-testid="main-collection" hook from v129.
//     Verified against three scenarios: a deeply-nested real dek (now correctly suppressed), a
//     genuinely separate headline elsewhere on the page (still correctly kept), and all three
//     collection-page teasers on a topic listing (still all correctly kept, unaffected by the
//     new order-based check). NOTE: this fix was built and tested against a reconstruction of
//     the reported case, not the live page itself -- worth confirming against the actual page
//     next time it's convenient.
//
// Changes from v129:
//   - Fixed zero variety on compound modifiers: "Administration"/"Family" each mapped to a
//     single, permanently fixed string ('Evil', 'Corrupt') with no randomization at all, unlike
//     the main modifier pool. Invisible in normal reading, but obvious the moment several
//     mentions cluster together (e.g. a "Tariffs and Economic Policy" story grid showing three
//     identical "The Evil Trump Administration" headlines in a row). findCompoundModifier() now
//     supports arrays and picks via getRandom() (the same recency-avoidance history buffer the
//     main pool uses), while staying backward-compatible with plain strings and null (still used
//     for deliberately-unmodified property/brand nouns like "Trump Tower"). Converted
//     Administration (7 options) and Family (5 options) to real pools, and activated Foundation
//     (previously null) with 4 options grounded in its real 2018 court-ordered dissolution over
//     fraud findings.
//   - Fixing the above surfaced two latent bugs elsewhere that assumed every compound modifier
//     was always a single string: alreadyContextualized() and alreadyModified() (the guards that
//     prevent double-modifying already-edited text) both called .replace()/.join() directly on
//     compound values, which crashed outright once a value became an array. Also fixed a related
//     spot in fixCompoundsEverywhere() building a regex via .join('|') on compound values, which
//     wouldn't have crashed but would have silently produced a broken, non-matching pattern.
//     All three now flatten arrays into individual modifier strings first. Verified end-to-end:
//     real variety confirmed across repeated trials for all three compounds, null compounds
//     (Organization, Tower, etc.) confirmed completely unaffected, and both guard functions
//     confirmed working (not crashing, correctly recognizing all variants) rather than just
//     checked for the absence of a crash.
//
// Changes from v128:
//   - Fixed missing name-keeping on NYT's Trump topic/collection page (e.g. nytimes.com's
//     dedicated "Donald Trump" tag listing). Each story teaser in that list is a plain <p>
//     wrapped in an auto-generated, build-hash class name (e.g. "css-1u7qftl") — not a real
//     heading tag — so it never entered the headline-detection pass at all, and each teaser
//     was falling through to ordinary body-text logic and losing the name after the first one.
//     Confirmed via inspector that the enclosing <section> carries a stable, semantic
//     data-testid="main-collection" attribute (unlike the auto-generated class names, this
//     won't change on NYT's next deploy). Added
//     '[data-testid="main-collection"] li p:first-child' to the headings selector so each
//     teaser is now correctly treated as an independent headline. Verified against a
//     reconstruction of the real DOM structure: all three teasers now correctly keep the name,
//     the summary/byline paragraphs after each headline are correctly excluded, and this
//     doesn't interact with or get suppressed by the v126 dek-detection fix (confirmed the
//     teasers aren't mistakenly treated as a dek of the page's own h1, since they sit in a
//     completely separate part of the DOM).
//
// Changes from v127 (content/copy edits, no logic changes):
//   - Added "shifty" and "bi-curious" to the modifier pool.
//
// Changes from v126 (content/copy edits, no logic changes):
//   - Hyphenated "pig fucker" -> "pig-fucker" for consistency with other compound insults
//     (shit-for-brains, bitch-ass, punk-bitch) and to match how it had actually rendered
//     ("Pig-Fucker") in earlier testing.
//   - Swapped "life enigma" for "evolutionary aberration" in the modifier pool.
//   - Reviewed the full modifier pool for hyphenation consistency. Confirmed "dipshit-in-Chief"
//     is correctly in properModifiers (no article, keeps its own capitalization) — the capital
//     "C" is intentional, matching real "Commander-in-Chief"-style title formatting, not a bug.
//
// Changes from v125:
//   - Fixed a dek/subhead bug: some sites (NYT confirmed) mark an article's dek as a genuine
//     semantic heading (e.g. <h2>) sitting directly under the <h1>. The heading pass treated
//     every matched heading as an independent "always keep the name" headline — necessary so
//     genuinely separate headlines elsewhere on a page (an unrelated teaser in a sidebar, a
//     different story on a section front) each correctly get their own first mention. But that
//     same generosity over-fired on a dek, which isn't a separate headline — it's part of the
//     same headline unit as the h1 immediately above it, and should inherit that unit's
//     introduced-state like ordinary body text would. Fixed by adding ctxIsDekOfHeading(),
//     which uses DOM proximity (shares a close common ancestor with the most recent h1) to
//     distinguish "this h2 is that h1's own dek" from "this h2 is an unrelated headline
//     elsewhere." Verified against both the real bug case (dek now correctly drops the name)
//     and the legitimate separate-headline case (still correctly keeps it) with realistic DOM
//     nesting depth matching actual news site structure.
//
// Changes from v123 (v124 only touched bookmarklet.js, no content.js changes):
//   - Added a remote kill-switch / domain blocklist. This extension is sideloaded, so there's
//     no auto-update mechanism — a hardcoded exclude list would only ever protect future
//     installs. Instead, fetches a small hosted list of blocked hostnames (a GitHub Gist raw
//     URL, evergreen — no revision hash, so edits to the gist take effect without needing a
//     new URL) at the start of every run, with a 1.2s timeout. If a domain is ever added to
//     the list, every already-installed copy respects it on its next page load. Fails OPEN on
//     any error (network failure, 404, timeout) — the extension just runs normally, exactly as
//     if this feature didn't exist. All existing init logic (previously top-level) is now
//     wrapped in ctxInit(), called only after the blocklist check clears. Requires
//     host_permissions for gist.githubusercontent.com in manifest.json for the cross-origin
//     fetch to work reliably from content scripts running on arbitrary third-party sites.
//
// Changes from v122:
//   - Fixed the remaining case of the "correct first mention gets overwritten" bug that v122
//     didn't cover: some re-renders don't edit an existing text node in place, they tear out a
//     whole block (in the confirmed case, several paragraphs at once) and mount brand new node
//     objects containing the same original, unmodified text. v122's fix only recognized "the
//     same node object being reset," so it missed this — the new node has different identity,
//     so introducerNode never matched, and the remounted paragraph fell through to the
//     "subsequent mention" branch and lost the name (confirmed via debug logging: a fresh
//     nodeId with byte-identical original text to the node that had already introduced the
//     subject). Now additionally tracks the exact original (pre-edit) text that introduced the
//     subject (state.introducerText) and re-arms "introduced" to false whenever that exact text
//     reappears unmodified, regardless of node identity. Genuinely different text elsewhere on
//     the page is unaffected and still correctly treated as a subsequent mention.
//
// Changes from v121:
//   - Fixed a race where a correct "first mention" (modifier + Trump) got silently overwritten
//     by an incorrect "subsequent mention" (modifier alone, name dropped) a moment later on the
//     same page. Cause: React sites sometimes reset a text node's content back to the original,
//     unmodified text after we've already edited it (a hydration pass, typically), and the
//     extension deliberately reprocesses that node when it detects this (see the characterData
//     handler) so the edit doesn't just vanish. But subjectState.introduced had already been set
//     true by the first pass, so the reprocessing pass treated its own earlier output as if some
//     other, separate mention had already appeared — even though it's the same node, and the
//     reader never saw anything but the final, wrongly-downgraded result. Now tracks which node
//     introduced each subject (state.introducerNode) and re-arms "introduced" to false when that
//     same node is reprocessed, so it correctly gets first-mention treatment again. Mentions from
//     genuinely different nodes are unaffected and still correctly treated as subsequent.
//
// Changes from v120:
//   - Fixed a stale-state bug on single-page apps (e.g. Gmail): subjectState.introduced is set
//     once at script load and never reset, so it silently persisted across different emails
//     viewed in the same tab (Gmail swaps content in-place, it never triggers a full page
//     reload). A Trump mention in an earlier email would leave "introduced" permanently true,
//     so a later email's own headline mention got treated as a subsequent mention and lost the
//     name entirely (e.g. "the hideous man's" instead of "the hideous man Trump's"). Now
//     detects SPA navigation (pushState/replaceState/hashchange/popstate) and resets
//     introduced-state on URL change, so each new message/article starts fresh again.
//
// Changes from v119:
//   - Fixed a Title Case bug where a modifier standing in for an isolated "Trump" mention
//     (e.g. a name split into its own DOM text node, as happens in some audio-caption blocks)
//     would render lowercase ("the tasteless") even inside a clearly Title Case headline.
//     isTitleCase() alone requires 2+ qualifying words and returns false on sparse/isolated
//     text, so it now has an ancestor-aware fallback: isTitleCaseWithContext() walks up to
//     4 parent elements and checks their tag/textContent when the local text is too sparse to
//     judge on its own. Applied to modifyText() and processCompoundNode() — the two places that
//     didn't already have this fallback (the Vance branch and fixCompoundsEverywhere already did).
//   - CTX_DEBUG reset to false for release (was left on in the v119 build).
// =============================================================================
// THE CONTEXTUALIZER — Subject Configuration
// Add new subjects here without touching the core logic below
// =============================================================================

// Debug logging — flip to true and reload to trace headline detection issues in the console
// (filter for "Contextualizer"). Safe to leave false; adds negligible overhead when off.
const CTX_DEBUG = false;

const SUBJECTS = [
  {
    // Match patterns for this subject
    patterns: [
      /\b(Mr\.\s+Trump|President\s+Donald\s+J\.?\s+Trump|President\s+Trump|Donald\s+J\.?\s+Trump|Donald\s+Trump|Trump)\b(?!-\w)([\u2019']s)?/g
    ],
    // Compound nouns with fixed modifiers (null = no modifier, leave pure)
    compounds: {
      'Administration': ['Evil', 'Corrupt', 'Criminal', 'Failed', 'Incompetent', 'Rogue', 'Lawless'],
      'Family':         ['Corrupt', 'Grifting', 'Criminal', 'Disgraced'],
      'Organization':   ['Evil', 'Corrupt', 'Criminal', 'Sketchy', 'Rotten'],
      'Tower':          ['Garish', 'Gaudy', 'Chintzy'],
      'Hotel':          ['Garish', 'Gaudy', 'Chintzy'],
      'International Hotel': ['Garish', 'Gaudy', 'Chintzy'],
      'Resort':         ['Garish', 'Gaudy', 'Chintzy'],
      'Golf Club':              ['Garish', 'Gaudy', 'Chintzy'],
      'Golf Course':            ['Garish', 'Gaudy', 'Chintzy'],
      'Golf Resort':            ['Garish', 'Gaudy', 'Chintzy'],
      'National Golf Club':     ['Garish', 'Gaudy', 'Chintzy'],
      'International Golf Club': ['Garish', 'Gaudy', 'Chintzy'],
      'National Golf Course':   ['Garish', 'Gaudy', 'Chintzy'],
      'Foundation':     ['Sham', 'Disgraced', 'Shifty', 'Fraudulent'],
      'Empire':         null,
    },
    // Rotating modifiers for this subject
    modifiers: [
      "stupid fuckhead", "shithead", "shit-for-brains", "convicted felon",
      "convicted sex offender", "sexual predator", "cad", "suspected rapist",
      "failed businessman", "failed real estate mogul", "racist", "white supremacist",
      "proud boy", "Aspiring Grand Dragon", "pathological liar", "worst human",
      "poor excuse of a human", "sad sack", "tiny hand man", "fuckface",
      "war criminal", "water sports enthusiast", "moron", "dipshit-in-Chief",
      "cretin", "public servant", "oaf", "disaster of a human",
      "orange stain", "complete asshole", "bigot", "trust fund baby", "hideous man",
      "habitual golfer", "cheat", "evolutionary aberration", "idiot", "loser", "bully",
      "sociopath", "bitch-ass", "freak", "mean man", "big dummy",
      "pig-fucker", "asshole", "malformed", "disgraced", "supreme jerk",
      "know-nothing", "magnificent dickhead", "Jeffrey Epstein confidant",
      "shyster", "career con man", "enemy of all things good", "dumbfuck",
      "shell of a man", "punk-bitch", "asshat", "Combover King",
      "Muppet", "strongman puppet", "oligarch", "donut", "dishonorable",
      "reality television personality", "tasteless", "clown IRL", "conniving",
      "uncouth", "dumbass", "doofus", "walking tumor",
      "autocrat", "dictator", "kleptocrat", "corrupt", "rube", "fool",
      "fraud", "bullshit artist", "disaster artist", "C-lister", "phony",
      "thief", "despot", "American oligarch",
  "philistine", "imbecile", "megalomaniac", "warmonger", "liar", "narcissist", "grifter", "has-been",
  "Big Mac pounder", "evil apologist", "KFC shoveler", "Nepo boss", "Fat Shady", "devious",
  "shifty", "bi-curious", "Kakistocracy Premier", "gold digger", "freeloader",
  "cis male", "vato loco", "wanker", "tosser", "gammon", "knob"
    ],
    // Proper modifiers: no "the", keep own capitalization
    properModifiers: new Set([
      "Aspiring Grand Dragon",
      "Jeffrey Epstein confidant",
      "Combover King",
      "American oligarch",
      "proud boy",
      "Nepo boss",
      "dipshit-in-Chief",
      "shit-for-brains",
      "has-been",
      "know-nothing",
      "C-lister",
      "Muppet",
      "Kakistocracy Premier"
    ]),
    // Solo modifiers: never attach the name, in any context (headline, first mention, or
    // subsequent) -- for nicknames/alter-egos that only work standing alone (e.g. "Fat Shady" as
    // a riff on Eminem's "Slim Shady": nobody says "The Slim Shady", and pairing it with "Donald
    // Trump" breaks the reference rather than just reading oddly).
    soloModifiers: new Set([
      "Fat Shady"
    ]),
    // Adjective-only modifiers: work fine paired with the name ("the shifty Trump"), but break
    // as a standalone subject once the name drops in a subsequent mention ("the shifty is the
    // 47th president..." -- missing a noun for the adjective to modify). Paired at render time
    // with a randomly-picked noun from adjectiveNouns, but only in that subsequent-mention case
    // -- headlines/first mentions already work fine with the name attached directly.
    adjectiveModifiers: new Set([
      "shifty", "corrupt", "devious", "disgraced", "dishonorable", "tasteless",
      "conniving", "uncouth", "malformed", "bi-curious", "bitch-ass"
    ]),
    adjectiveNouns: [
      "President", "US Leader", "World Leader", "Head of State", "Tool"
    ],
  },
  {
    patterns: [
      /\b(Vice\s+President\s+(?:J\.?D\.?\s+Vance|Vance)|J\.?D\.?\s+Vance|Vance)([\u2019']s)?/g
    ],
    compounds: {},
    modifiers: ["lap dog"],
    properModifiers: new Set(),
    useInnerHTML: true,  // Use innerHTML approach to handle split DOM text nodes
  },
  // ── Add new subjects below this line ──────────────────────────────────────
  // {
  //   patterns: [ /\b(Elon\s+Musk|Musk)([\u2019']s)?/g ],
  //   compounds: {},
  //   modifiers: ["world's richest troll", "feudal overlord", "attention-seeking billionaire"],
  //   properModifiers: new Set(),
  // },
];

// =============================================================================
// Core Logic — no need to edit below here
// =============================================================================

const titleCaseSmallWords = new Set([
  "a", "an", "the", "and", "but", "or", "for", "nor", "on", "at",
  "to", "by", "in", "of", "up", "as", "is", "it", "its"
]);

// Per-array recent history buffers to avoid repeat modifiers
const recentHistory = new Map();
// Was 5 -- far too small for a busy page: a single view can easily have 7+ independent headline
// mentions (main headline, several story teasers, related-content links), and with only 5 slots
// remembered, an early pick ages out of the window before the page is done rendering, letting the
// same modifier resurface later in the same view (confirmed: "Oligarch" used twice on one NYT
// topic-page screenshot). Pool is 108 words; 40 comfortably covers any realistically busy single
// page while leaving plenty of the pool still fresh, rather than requiring the entire pool
// exhausted before any repeat is allowed.
const HISTORY_BUFFER = 40;

function getRandom(arr) {
  if (arr.length <= 1) return arr[0];
  if (!recentHistory.has(arr)) recentHistory.set(arr, []);
  const recent = recentHistory.get(arr);
  // Filter out recently used modifiers
  const available = arr.filter(m => !recent.includes(m));
  const pick = available.length > 0
    ? available[Math.floor(Math.random() * available.length)]
    : arr[Math.floor(Math.random() * arr.length)];
  // Update history
  recent.push(pick);
  if (recent.length > HISTORY_BUFFER) recent.shift();
  return pick;
}

function isStartOfSentence(text, matchIndex) {
  if (matchIndex === 0) return true;
  const before = text.slice(0, matchIndex);
  const trimmed = before.trimEnd();
  if (trimmed.length === 0) return true;
  return /[.!?]$/.test(trimmed);
}

function isTitleCase(text) {
  const words = text.match(/\b[a-zA-Z]{4,}\b/g);
  if (!words || words.length < 2) return false;
  const capitalizedCount = words.filter(w => /^[A-Z]/.test(w)).length;
  const ratio = capitalizedCount / words.length;
  const isShort = text.trim().split(/\s+/).length <= 15;
  return ratio >= (isShort ? 0.45 : 0.6);
}

// isTitleCase() only has the local text to go on, and returns false whenever that text has
// fewer than 2 words of length >= 4 — which happens whenever a site's DOM isolates a name
// (e.g. "Trump") in its own text node, split away from the rest of the headline/caption. That
// caused a real bug: a modifier standing in for an isolated "Trump" mention (e.g. an audio-player
// caption) would render lowercase ("the tasteless") even though the surrounding headline was
// clearly Title Case, because isTitleCase("Trump") alone has only 1 qualifying word and bails out
// before checking capitalization at all.
//
// This wraps isTitleCase() with the same ancestor-walking fallback already used for the Vance
// branch (see processElementHTML below) and in fixCompoundsEverywhere: if the local text is too
// sparse to judge, walk up a few parent elements and judge from their full text content instead.
function isTitleCaseWithContext(text, node) {
  if (isTitleCase(text)) return true;
  let el = node && node.parentElement;
  for (let i = 0; i < 4; i++) {
    if (!el) break;
    const tag = (el.tagName || '').toLowerCase();
    if (['h1', 'h2', 'h3', 'h4', 'h5', 'h6'].includes(tag)) return true;
    if (isTitleCase(el.textContent || '')) return true;
    el = el.parentElement;
  }
  return false;
}

// Capitalizes just the first letter, leaving the rest of the string untouched. Used for proper
// modifiers (no article) that happen to open a sentence/headline — e.g. "dipshit-in-Chief" stored
// lowercase-first must still read "Dipshit-in-Chief" when it's literally the first word.
// Looks up a compound noun (e.g. "Administration") case-insensitively, since regex captures
// preserve the source text's original casing (e.g. "administration" mid-sentence vs
// "Administration" capitalized) but object key lookups are case-sensitive. Without this, a
// lowercase compound noun would silently miss its fixed modifier (e.g. "Evil") and — worse —
// get dropped entirely by branches that don't know to re-append it. Returns the modifier value
// (which may legitimately be null, meaning "pure, no modifier"), or undefined if the noun isn't
// a recognized compound at all.
function findCompoundModifier(compoundsObj, capturedNoun) {
  if (!capturedNoun) return { found: false, modifier: undefined };
  const key = Object.keys(compoundsObj).find(k => k.toLowerCase() === capturedNoun.toLowerCase());
  if (!key) return { found: false, modifier: undefined };
  const value = compoundsObj[key];
  // Compounds can be a fixed string (legacy/simple case), an array (real variety, picked via
  // getRandom() -- same recency-avoidance history buffer the main modifier pool uses, keyed
  // independently per array), or null (deliberately left unmodified, e.g. property/brand nouns
  // like "Trump Tower").
  const modifier = Array.isArray(value) ? getRandom(value) : value;
  return { found: true, modifier };
}

function capitalizeFirst(str) {
  if (!str) return str;
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function toTitleCase(str, isHeadline) {
  return str.split(' ').map((word, index) => {
    if (index !== 0 && titleCaseSmallWords.has(word.toLowerCase())) {
      return word.toLowerCase();
    }
    if (word.includes('-')) {
      const parts = word.split('-');
      if (isHeadline) {
        return parts.map((part, i) => {
          if (i > 0 && i < parts.length - 1 && titleCaseSmallWords.has(part.toLowerCase())) {
            return part.toLowerCase();
          }
          return part.charAt(0).toUpperCase() + part.slice(1).toLowerCase();
        }).join('-');
      }
      return parts.map((part, i) => {
        if (i === 0) return part.charAt(0).toUpperCase() + part.slice(1).toLowerCase();
        if (part.toLowerCase() === 'chief') return 'Chief';
        if (part.toLowerCase() === 'brains') return 'Brains';
        return part.toLowerCase();
      }).join('-');
    }
    return word.charAt(0).toUpperCase() + word.slice(1);
  }).join(' ');
}

function isInNavigation(node) {
  // Genuine headline-shaped content (e.g. Fox's "More on Donald Trump" sidebar recirculation
  // module, with real <h4 class="title"> headlines) should still get modified even when it lives
  // inside a "sidebar" element for layout reasons. The sidebar exclusion below exists to catch
  // bare topic-tag links (e.g. NYT's plain "Donald Trump" link) that aren't wrapped in an actual
  // heading — so only skip the sidebar exclusion when the text is genuinely inside a heading.
  const parentEl = node.parentElement;
  const inHeadingContext = !!(parentEl && parentEl.closest && parentEl.closest(
    'h1, h2, h3, h4, h5, h6, [data-testid="headline"], [data-tpl="h"], [data-tpl="f"], [data-tpl="sli"], [data-tpl="slic"], .indicate-hover, [data-editable="headline"]'
  ));
  let el = node.parentElement;
  while (el) {
    const tag = el.tagName ? el.tagName.toLowerCase() : '';
    const role = (el.getAttribute && el.getAttribute('role') || '').toLowerCase();
    const cls = (el.className && typeof el.className === 'string') ? el.className.toLowerCase() : '';
    // Skip actual nav elements
    if (tag === 'nav') return true;
    if (role === 'navigation' || role === 'menubar' || role === 'menu') return true;
    // Only block site-level headers, not article-level ones
    if (tag === 'header' && (
      el.parentElement === document.body ||
      role === 'banner' ||
      cls.includes('site-header') ||
      cls.includes('site-nav') ||
      cls.match(/\bnav\b/) ||
      cls.match(/\bmenu\b/)
    )) return true;
    // Whole-word sidebar match, but not content areas that happen to include "sidebar", and not
    // genuine headline text that just happens to be laid out in a sidebar module.
    if (cls.match(/\bsidebar\b/) && !cls.includes('content') && !inHeadingContext) return true;
    if (cls.match(/\bbreadcrumb\b/)) return true;
    el = el.parentElement;
  }
  return false;
}

// Per-subject state: tracks whether subject has been introduced in body text
const subjectState = SUBJECTS.map(() => ({ introduced: false, introducerNode: null, introducerText: null }));

// Modifier cache keyed by original text
const modifierCache = new Map();

// Track already-processed text nodes to prevent stacking in nested HTML (e.g. emails)
const processedTextNodes = new WeakSet();

// Detect stacking: if our modifiers already appear in the text, skip processing
function alreadyContextualized(text) {
  // Check if text already contains one of our modifiers immediately before a name pattern.
  // This catches React-rerendered nodes that are new DOM objects (bypassing processedTextNodes WeakSet)
  // but whose text content was already modified by a prior pass.
  return SUBJECTS.some(subject => {
    const randomModifierMatch = subject.modifiers.some(modifier => {
      const escaped = modifier.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      // Match "the <modifier> <name>" or "<modifier> <name>" (for proper modifiers)
      return new RegExp(`(?:the\\s+)?${escaped}\\s+(?:President\\s+|Donald\\s+)?Trump`, 'i').test(text)
        || new RegExp(`(?:the\\s+)?${escaped}['\\u2019]s`, 'i').test(text)
        || new RegExp(`^(?:the\\s+)?${escaped}$`, 'i').test(text.trim());
    });
    if (randomModifierMatch) return true;

    // Also check fixed compound modifiers (e.g. "Evil" before "Trump Administration"),
    // which live in a separate structure and were previously invisible to this guard —
    // that gap let a text node get double-modified into "The Evil The Evil Trump Administration".
    // Compound values can be a plain string OR an array of options (for variety) -- flatten both
    // into individual modifier strings so every possible variant is recognized, not just one.
    const compoundValues = Object.values(subject.compounds || {})
      .filter(Boolean)
      .flatMap(v => (Array.isArray(v) ? v : [v]));
    return compoundValues.some(compoundModifier => {
      const escaped = compoundModifier.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      return new RegExp(`(?:the\\s+)?${escaped}\\s+(?:President\\s+|Donald\\s+)?Trump`, 'i').test(text);
    });
  });
}

function buildModifyFn(subject, state) {
  const { modifiers, properModifiers, compounds } = subject;
  const soloModifiers = subject.soloModifiers || new Set();
  const adjectiveModifiers = subject.adjectiveModifiers || new Set();
  const adjectiveNouns = subject.adjectiveNouns || [];
  const compoundNames = Object.keys(compounds).filter(k => compounds[k] !== null);
  const compoundPattern = compoundNames.length
    ? new RegExp(`([Tt]he\\s+)?\\b(${subject.patterns[0].source.replace(/\(.*?\)/g, (m) => m)})([\u2019']s)?(\\s+(${compoundNames.join('|')})\\b)?`, 'g')
    : null;

  return function modifyText(text, isHeadline, contextTitleCase, node) {
    if (alreadyContextualized(text)) return text;
    // Prefer the caller-supplied ancestor-aware hint (see isTitleCaseWithContext) when given;
    // otherwise fall back to judging from this text alone.
    const titleCase = contextTitleCase !== undefined ? contextTitleCase : isTitleCase(text);
    const treatAsHeadline = !!isHeadline; // DOM-based: true h1/h2/h3 etc., regardless of casing style

    // If this exact text node previously introduced the subject, but is being reprocessed here,
    // treat it as the first mention again rather than a subsequent one. This happens when a site
    // (React apps especially) resets a text node's content back to the original, unmodified text
    // after we've already edited it — the characterData handler below deliberately un-guards
    // nodes for this reason, since otherwise the edit would just silently vanish. Without this
    // check, the earlier "first mention" output (which the reader may have glimpsed only
    // fleetingly before the page settled) permanently consumes the introduction slot, and the
    // version the reader actually ends up seeing gets the "subsequent mention" treatment and
    // loses the name — even though it's the only mention they'll ever see.
    //
    // Node identity alone isn't enough, though: some re-renders don't edit the existing text node
    // in place, they tear out the whole subtree and mount a brand new node with the same original
    // (unmodified) text — e.g. a whole paragraph block remounting at once. That's a genuinely
    // different node object, so introducerNode never matches even though it's the same logical
    // mention. Guard against that too by remembering the exact original (pre-edit) text that
    // introduced the subject — if that exact text shows up again unmodified, it's essentially
    // certain to be the same mention being re-rendered from scratch, not a coincidental second
    // occurrence of byte-identical prose elsewhere on the page.
    if ((node && state.introducerNode === node) || (state.introducerText !== null && text === state.introducerText)) {
      state.introduced = false;
    }

    // Build a single pattern that optionally captures compound nouns
    const compoundList = Object.keys(compounds);
    const namePattern = subject.patterns[0];
    // Reset lastIndex
    const fullPattern = new RegExp(
      `([Tt]he\\s+)?` +
      namePattern.source.replace(/\/g$/, '') +
      `(\\s+(${compoundList.join('|')})\\b)?`,
      'gi'
    );

    // Track offsets already replaced to prevent double-matching (e.g. "President Trump" then "Trump")
    const replacedRanges = [];

    return text.replace(fullPattern, (fullMatch, thePrefix, name, possessive, compoundSuffix, compoundNoun, offset) => {
      // Skip if this range was already replaced by a longer match
      const end = offset + fullMatch.length;
      if (replacedRanges.some(([s, e]) => offset >= s && offset < e)) return fullMatch;
      replacedRanges.push([offset, end]);

      const sentenceStart = isStartOfSentence(text, offset);
      // Keep the original name exactly as written — preserve article's own honorifics/style
      const cleanName = name;

      // Handle split DOM nodes where "Vance" is isolated in its own text node
      const isVanceAlone = name === 'Vance' && text.trim() === 'Vance';
      const isVanceAtEnd = name === 'Vance' && /Vance$/.test(text.trim());
      const trailingSpace = (isVanceAlone || isVanceAtEnd) ? ' ' : '';

      // Compound handling
      const compoundLookup = findCompoundModifier(compounds, compoundNoun);
      if (compoundLookup.found) {
        const fixedModifier = compoundLookup.modifier;
        if (!fixedModifier) return fullMatch; // pure, no modifier
        const cap = titleCase ? fixedModifier.charAt(0).toUpperCase() + fixedModifier.slice(1) : fixedModifier.toLowerCase();
        const the = thePrefix ? thePrefix : (titleCase ? 'The ' : 'the ');
        return `${the}${cap} ${cleanName}${possessive || ''}${compoundSuffix}`;
      }

      const modifier = getRandom(modifiers);

      // Solo modifiers (e.g. "Fat Shady") never attach the name, in any context -- render them
      // exactly as stored, standing completely alone, regardless of headline/first/subsequent
      // mention. Still marks the subject as introduced (a reader now knows who's being referred
      // to, alter-ego or not), so later ordinary modifiers elsewhere on the page still correctly
      // drop the name.
      if (soloModifiers.has(modifier)) {
        if (!state.introduced) {
          state.introduced = true;
          state.introducerNode = node || null;
          state.introducerText = text;
        }
        return `${modifier}${possessive || ''}${trailingSpace || ''}`;
      }

      const isProper = properModifiers.has(modifier);
      const article = sentenceStart ? 'The' : 'the';

      // Headlines always get modifier + original name, regardless of processing order elsewhere on the page
      if (treatAsHeadline) {
        state.introduced = true;
        state.introducerNode = node || null;
        state.introducerText = text;
        // Only force full Title Case when the headline itself is title-cased (e.g. NYT). Some
        // sites (e.g. Fox News) use sentence-case headlines, where forcing "The Cretin" style
        // capitalization mid-headline stands out against the site's own style guide — in that
        // case, preserve the modifier's natural stored casing instead (matches the same
        // titleCase-conditional pattern already used in the body-mention branches below).
        const displayModifier = titleCase ? toTitleCase(modifier, true) : modifier;
        const headlineArticle = sentenceStart ? 'The' : 'the';
        // Non-proper modifiers get their sentence-initial capital from "The"/"the" above. Proper
        // modifiers skip the article entirely, so without this they'd stay lowercase even when
        // they're literally the first word of the headline (capitalizeFirst is a harmless no-op
        // when titleCase already capitalized it).
        if (isProper) return `${sentenceStart ? capitalizeFirst(displayModifier) : displayModifier} ${cleanName}${possessive || ''}${trailingSpace || ''}`;
        return `${headlineArticle} ${displayModifier} ${cleanName}${possessive || ''}${trailingSpace || ''}`;
      }

      // Subsequent body mentions (after first introduction): modifier alone, name dropped.
      // displayModifier/displayNoun deliberately do NOT consult titleCase here (see note above
      // the first-body-mention branch below for why) -- sentence-start capitalization is already
      // handled correctly by "article" (The/the) or capitalizeFirst for proper modifiers.
      if (state.introduced) {
        const displayModifier = modifier;
        if (isProper) return `${sentenceStart ? capitalizeFirst(displayModifier) : displayModifier}${possessive || ''}${trailingSpace || ''}`;
        if (adjectiveModifiers.has(modifier) && adjectiveNouns.length) {
          const noun = getRandom(adjectiveNouns);
          // Lowercase normally, but preserve standalone all-caps acronyms (e.g. "US") as-is --
          // blanket-lowercasing would turn "US Leader" into "us leader", which reads like a typo
          // or the pronoun "us" rather than the acronym.
          const displayNoun = noun.split(' ').map(w => (w.length > 1 && w === w.toUpperCase()) ? w : w.toLowerCase()).join(' ');
          return `${article} ${displayModifier} ${displayNoun}${possessive || ''}${trailingSpace || ''}`;
        }
        return `${article} ${displayModifier}${possessive || ''}${trailingSpace || ''}`;
      }

      // First body mention: modifier + original name, preserved intact — usually placed BEFORE
      // the name ("the lap dog Vance"), but 25% of the time placed AFTER instead, as an
      // appositive ("Vance, the lap dog,") for variety. This was an established rule from early
      // in the project that content.js's own logic never actually implemented -- only
      // bookmarklet.js's separate, older codebase had it, which is why every mention on a page
      // like a "JD Vance" topic listing came out modifier-first every single time. Forced to
      // "before" when there's a possessive (a trailing "'s" doesn't read well with the
      // appositive form) or when the match sits at/near the end of the sentence (no room for a
      // trailing appositive to attach to). Also fixes two gaps in bookmarklet.js's original
      // version of this: it hardcoded lowercase "the" in the after-branch regardless of
      // titleCase or sentenceStart, and never checked isProper there at all -- meaning a proper
      // modifier like "Fat Shady" would have incorrectly gotten an article in that branch
      // ("Vance, the Fat Shady,"), the one thing properModifiers exists to prevent.
      //
      // displayModifier deliberately does NOT consult titleCase either, for a related but
      // distinct reason: titleCase is computed from ancestor context (see
      // isTitleCaseWithContext), including "is this wrapped in an h1-h6 tag" -- which is exactly
      // true for a dek (a real heading tag, just one this pipeline has already determined isn't
      // an independent headline for naming purposes). That conflated two different questions:
      // "should this mention keep the name" (correctly handled by treatAsHeadline/dek-detection)
      // and "is this text actually styled in Title Case" (which a dek usually isn't -- it's
      // normal sentence-case prose, same as the rest of a news source's body copy, even though
      // it sits in a heading tag). Confirmed with a real example: "World Leader" -- a two-word
      // companion noun -- rendered fully title-cased ("The Tasteless World Leader") in a dek,
      // even though the dek's own surrounding sentence ("is the 47th president of the United
      // States...") was plainly normal sentence-case prose the whole time; it just wasn't
      // visible with single-word modifiers, where "capitalize the whole word" and "capitalize
      // just the first letter" look identical. Tightening isTitleCaseWithContext wouldn't have
      // been enough on its own either: even without the h1-h6 shortcut, the sentence's own
      // ratio-based check independently misfires here too, since a short sentence containing a
      // two-word proper noun ("United States") pushes the capitalized-word ratio over threshold
      // on its own. Matches the news source's own actual style instead: sentence case, proper
      // nouns aside, which is already exactly what article/capitalizeFirst produce on their own
      // without any title-case transform layered on top.
      state.introduced = true;
      state.introducerNode = node || null;
      state.introducerText = text;
      const displayModifier = modifier;
      const afterMatch = text.slice(offset + fullMatch.length).trim();
      const isAtEnd = afterMatch.length === 0 || /^[.!?,;]/.test(afterMatch);
      const forceBefore = !!possessive || isAtEnd;
      const before = forceBefore || Math.random() < 0.75;
      if (before) {
        if (isProper) return `${sentenceStart ? capitalizeFirst(displayModifier) : displayModifier} ${cleanName}${possessive || ''}${trailingSpace || ''}`;
        return `${article} ${displayModifier} ${cleanName}${possessive || ''}${trailingSpace || ''}`;
      }
      if (isProper) return `${cleanName}, ${displayModifier},${trailingSpace || ''}`;
      return `${cleanName}, ${article.toLowerCase()} ${displayModifier},${trailingSpace || ''}`;
    });
  };
}

// Build modify functions for each subject
const subjectModifyFns = SUBJECTS.map((subject, i) => buildModifyFn(subject, subjectState[i]));

function processTextForSubject(text, subjectIndex, isHeadline, contextTitleCase, node) {
  return subjectModifyFns[subjectIndex](text, isHeadline, contextTitleCase, node);
}

// Build a regex that detects already-modified compound phrases across all subjects
function alreadyModified(text) {
  return SUBJECTS.some(subject => {
    return Object.entries(subject.compounds).some(([noun, value]) => {
      if (!value) return false;
      const variants = Array.isArray(value) ? value : [value];
      return variants.some(modifier => {
        const escaped = modifier.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        return new RegExp(`\\b${escaped}\\s+(President\\s+)?Trump\\s+${noun}\\b`, 'i').test(text);
      });
    });
  });
}

// Process an element's innerHTML for Vance references (handles split text nodes)
const processedElements = new WeakSet();

function processElementHTML(element) {
  if (processedElements.has(element)) return;
  const plainText = element.textContent || '';
  if (!/\bVance\b/.test(plainText)) return;
  // Skip if already modified
  if (/Lap Dog/.test(plainText)) return;
  // Mark as processed immediately to prevent re-entry
  processedElements.add(element);

  // Skip section headers — check direct text content of this element only (not children)
  const directText = Array.from(element.childNodes)
    .filter(n => n.nodeType === Node.TEXT_NODE)
    .map(n => n.nodeValue.trim())
    .join('').trim();
  if (directText.length < 30 || /^(JD\s+Vance|J\.D\.\s+Vance|Vice\s+President\s+Vance)$/i.test(directText)) return;
  const trimmed = plainText.trim();
  if (trimmed.length < 30) return;

  // For Vance headlines: check title case, but also check ancestor elements for heading context
  let titleCase = isTitleCase(plainText);
  if (!titleCase) {
    // Walk up to 4 levels to see if we're inside a heading or headline container
    let el = element;
    for (let i = 0; i < 4; i++) {
      if (!el) break;
      const t = (el.tagName || '').toLowerCase();
      if (['h1','h2','h3','h4','h5','h6'].includes(t)) { titleCase = true; break; }
      // NYT headline links are inside p tags with specific patterns
      if (t === 'p' && isTitleCase(el.textContent || '')) { titleCase = true; break; }
      el = el.parentElement;
    }
  }

  SUBJECTS.forEach((subject, i) => {
    if (!subject.useInnerHTML) return;
    const state = subjectState[i];

    const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, null);
    const textNodes = [];
    let n;
    while ((n = walker.nextNode())) textNodes.push(n);

    textNodes.forEach(node => {
      const orig = node.nodeValue;
      if (!/\bVance\b/.test(orig)) return;

      const modified = orig.replace(
        /\b(Vice\s+President\s+(?:J\.?D\.?\s*Vance|Vance)|J\.?D\.?\s*Vance|Vance)([\u2019\']s)?/g,
        (fullMatch, name, possessive, offset) => {
          const sentenceStart = isStartOfSentence(orig, offset);
          const article = (sentenceStart || titleCase) ? 'The' : 'the';
          // processElementHTML only handles headline/card contexts — always use Lap Dog
          const art = sentenceStart ? 'The' : 'the';

          // Always include full name in headlines for context
          if (state.introduced) {
            return art + ' Lap Dog ' + name + (possessive || '');
          }
          state.introduced = true;
          return art + ' Lap Dog ' + name + (possessive || '');
        }
      );

      if (modified !== orig) {
        node.nodeValue = modified;
      }
    });
  });
}


function processTextNode(node, isHeadline) {
  const dbg = CTX_DEBUG && /Trump/.test(node.nodeValue || '');
  // Skip if this exact text node has already been processed
  if (processedTextNodes.has(node)) {
    if (dbg) console.log('[Contextualizer] SKIP (already processed):', JSON.stringify((node.nodeValue||'').slice(0,60)));
    return;
  }
  // Mark as processed immediately — prevents double-modification if a MutationObserver
  // event fires again on this same node (e.g. live-updating modules re-touching the DOM)
  processedTextNodes.add(node);

  // Hard safety net: never process navigation text, regardless of which pass/caller reached this node.
  // This guards against nav links (e.g. NYT's "Donald Trump" topic tag) silently consuming the
  // first-mention slot even when the walker's own filter should have already excluded them.
  if (isInNavigation(node)) {
    if (dbg) console.log('[Contextualizer] SKIP (isInNavigation=true), isHeadline:', isHeadline, JSON.stringify((node.nodeValue||'').slice(0,60)));
    return;
  }

  let text = node.nodeValue;
  let modified = false;

  // Skip if already modified by compound pass
  if (alreadyModified(text)) {
    if (dbg) console.log('[Contextualizer] SKIP (alreadyModified=true):', JSON.stringify(text.slice(0,60)));
    return;
  }

  if (dbg) console.log('[Contextualizer] PROCESSING, isHeadline:', isHeadline, JSON.stringify(text.slice(0,60)));

  // Judge Title Case from this node's own text, falling back to ancestor context when the node's
  // text is too sparse to judge alone (e.g. a name isolated in its own text node — see
  // isTitleCaseWithContext for the full explanation of why this matters).
  const contextTitleCase = isTitleCaseWithContext(text, node);

  SUBJECTS.forEach((subject, i) => {
    if (subject.useInnerHTML) return; // handled by processElementHTML
    const pattern = new RegExp(subject.patterns[0].source, 'g');
    if (!pattern.test(text)) return;
    const newText = processTextForSubject(text, i, isHeadline, contextTitleCase, node);
    if (newText !== text) {
      text = newText;
      modified = true;
    }
  });

  if (dbg) console.log('[Contextualizer] RESULT modified:', modified, JSON.stringify(text.slice(0,60)));

  if (modified) node.nodeValue = text;
}

// Compound-only pass for nav elements (Administration, Family etc.)
function processCompoundNode(node) {
  // This function previously had no reprocessing guard at all, unlike processTextNode and the
  // (now-patched) fixCompoundsEverywhere — it would happily re-run its regex against text that
  // was already compound-modified by an earlier pass, producing "The Evil The Evil Trump
  // Administration" style doubling. Guard it the same way the other two paths are guarded.
  const dbg = CTX_DEBUG && /Trump/.test(node.nodeValue || '');
  if (processedTextNodes.has(node)) {
    if (dbg) console.log('[Contextualizer] processCompoundNode SKIP (already processed):', JSON.stringify((node.nodeValue||'').slice(0,80)));
    return;
  }
  let text = node.nodeValue;
  if (alreadyModified(text)) {
    if (dbg) console.log('[Contextualizer] processCompoundNode SKIP (alreadyModified):', JSON.stringify(text.slice(0,80)));
    processedTextNodes.add(node); return;
  }
  if (dbg) console.log('[Contextualizer] processCompoundNode ENTER:', JSON.stringify(text.slice(0,80)));
  let modified = false;

  // First try single node match
  SUBJECTS.forEach((subject) => {
    const compoundNames = Object.keys(subject.compounds).filter(k => subject.compounds[k] !== null);
    if (!compoundNames.length) return;
    const pattern = new RegExp(
      `([Tt]he\\s+)?\\b(President\\s+Trump|Trump)([\\u2019']s)?(\\s+(${compoundNames.join('|')})\\b)`,
      'gi'
    );
    const titleCase = isTitleCaseWithContext(text, node);
    const newText = text.replace(pattern, (fullMatch, thePrefix, name, possessive, compoundSuffix, compoundNoun) => {
      const { modifier: fixedModifier } = findCompoundModifier(subject.compounds, compoundNoun);
      if (!fixedModifier) return fullMatch;
      const cap = titleCase
        ? fixedModifier.charAt(0).toUpperCase() + fixedModifier.slice(1)
        : fixedModifier.toLowerCase();
      const the = thePrefix ? thePrefix : (titleCase ? 'The ' : 'the ');
      return `${the}${cap} ${name}${possessive || ''}${compoundSuffix}`;
    });
    if (newText !== text) { text = newText; modified = true; }
  });

  if (modified) {
    if (dbg) console.log('[Contextualizer] processCompoundNode MODIFIED (single-node):', JSON.stringify(text.slice(0,80)));
    node.nodeValue = text; processedTextNodes.add(node); return;
  }

  // Try combining with next sibling text node (handles split DOM nodes)
  if (!/Trump/.test(text)) return;
  const next = node.nextSibling;
  if (!next || next.nodeType !== Node.TEXT_NODE) return;

  const combined = text + next.nodeValue;
  if (alreadyModified(combined)) { processedTextNodes.add(node); processedTextNodes.add(next); return; }
  SUBJECTS.forEach((subject) => {
    const compoundNames = Object.keys(subject.compounds).filter(k => subject.compounds[k] !== null);
    if (!compoundNames.length) return;
    const pattern = new RegExp(
      `([Tt]he\\s+)?\\b(President\\s+Trump|Trump)([\\u2019']s)?(\\s+(${compoundNames.join('|')})\\b)`,
      'gi'
    );
    if (!pattern.test(combined)) return;
    const titleCase = isTitleCaseWithContext(combined, node);
    const newCombined = combined.replace(pattern, (fullMatch, thePrefix, name, possessive, compoundSuffix, compoundNoun) => {
      const { modifier: fixedModifier } = findCompoundModifier(subject.compounds, compoundNoun);
      if (!fixedModifier) return fullMatch;
      const cap = titleCase
        ? fixedModifier.charAt(0).toUpperCase() + fixedModifier.slice(1)
        : fixedModifier.toLowerCase();
      const the = thePrefix ? thePrefix : (titleCase ? 'The ' : 'the ');
      return `${the}${cap} ${name}${possessive || ''}${compoundSuffix}`;
    });
    if (newCombined !== combined) {
      node.nodeValue = newCombined;
      next.nodeValue = '';
      processedTextNodes.add(node);
      processedTextNodes.add(next);
    }
  });
}

function walkTextNodes(root, compoundOnly, isHeadline) {
  const walker = document.createTreeWalker(
    root,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode(node) {
        const dbg = CTX_DEBUG && /Trump/.test(node.nodeValue || '');
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;
        const tag = parent.tagName;
        if (["SCRIPT", "STYLE", "NOSCRIPT", "TEXTAREA"].includes(tag)) return NodeFilter.FILTER_REJECT;
        if (!compoundOnly && isInNavigation(node)) {
          if (dbg) console.log('[Contextualizer] TreeWalker REJECT (isInNavigation), isHeadline:', isHeadline, JSON.stringify((node.nodeValue||'').slice(0,60)));
          return NodeFilter.FILTER_REJECT;
        }
        // Some site card containers (e.g. NYT's data-tpl="sli"/"slic"/"f" wrappers) bundle the
        // headline AND the blurb/summary text under one element with a shared <a>. When we're
        // running the headline pass, exclude anything inside a known blurb/summary block so it
        // isn't forced into isHeadline=true treatment (which would always keep the name).
        if (isHeadline && parent.closest('[data-tpl="bo"]')) {
          if (dbg) console.log('[Contextualizer] TreeWalker REJECT (data-tpl=bo), isHeadline:', isHeadline, JSON.stringify((node.nodeValue||'').slice(0,60)));
          return NodeFilter.FILTER_REJECT;
        }
        if (dbg) console.log('[Contextualizer] TreeWalker ACCEPT, isHeadline:', isHeadline, JSON.stringify((node.nodeValue||'').slice(0,60)));
        return NodeFilter.FILTER_ACCEPT;
      }
    }
  );
  const nodes = [];
  let node;
  while ((node = walker.nextNode())) nodes.push(node);
  nodes.forEach(n => compoundOnly ? processCompoundNode(n) : processTextNode(n, isHeadline));
}

function walkElementsForHTML(root) {
  const hasInnerHTML = SUBJECTS.some(s => s.useInnerHTML);
  if (!hasInnerHTML) return;

  const walker = document.createTreeWalker(
    root,
    NodeFilter.SHOW_ELEMENT,
    {
      acceptNode(node) {
        const tag = node.tagName ? node.tagName.toLowerCase() : '';
        if (["script", "style", "noscript", "textarea"].includes(tag)) return NodeFilter.FILTER_REJECT;
        // Only skip actual nav/menu elements — NOT section/collection containers
        const role = (node.getAttribute && node.getAttribute('role') || '').toLowerCase();
        if (tag === 'nav' || role === 'navigation' || role === 'menubar') return NodeFilter.FILTER_REJECT;
        if (["h1","h2","h3","h4","h5","h6","p","a","li","span","div"].includes(tag)) {
          return NodeFilter.FILTER_ACCEPT;
        }
        return NodeFilter.FILTER_SKIP;
      }
    }
  );
  const elements = [];
  let el;
  while ((el = walker.nextNode())) elements.push(el);
  elements.forEach(processElementHTML);
}

// Fix compound modifications everywhere using querySelectorAll
const compoundProcessed = new WeakSet();

function fixCompoundsEverywhere(root) {
  const elements = root.querySelectorAll('a, span, div, p, li, header, nav, section, h1, h2, h3, h4, h5, h6');
  elements.forEach(el => {
    if (compoundProcessed.has(el)) return;
    const text = el.textContent || '';
    if (!/Trump/.test(text)) return;
    const dbg = CTX_DEBUG && /President.*Trump/.test(text);
    // Only process if this element has no child elements that also contain Trump
    const childrenWithTrump = Array.from(el.children).filter(c => /Trump/.test(c.textContent || ''));
    if (childrenWithTrump.length > 0) return;
    if (dbg) console.log('[Contextualizer] fixCompoundsEverywhere examining el:', el.tagName, JSON.stringify(text.slice(0, 100)));

    SUBJECTS.forEach(subject => {
      const compoundNames = Object.keys(subject.compounds).filter(k => subject.compounds[k] !== null);
      if (!compoundNames.length) return;
      const pattern = new RegExp(
        `([Tt]he\\s+)?\\b(President\\s+Trump|Trump)([\\u2019']s)?(\\s+(${compoundNames.join('|')})\\b)`,
        'gi'
      );
      // Re-read textContent fresh to catch modifications made by child elements
      const allCompoundVariants = Object.values(subject.compounds).filter(Boolean).flatMap(v => (Array.isArray(v) ? v : [v]));
      if (allCompoundVariants.length && new RegExp(allCompoundVariants.join('|'), 'i').test(el.textContent || '')) return;
      if (!pattern.test(text)) return;

      const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null);
      const textNodes = [];
      let n;
      while ((n = walker.nextNode())) textNodes.push(n);

      for (let i = 0; i < textNodes.length; i++) {
        const node = textNodes[i];
        const single = node.nodeValue;
        const titleCase = isTitleCase(single) || isTitleCase(text);

        if (pattern.test(single)) {
          pattern.lastIndex = 0;
          const newVal = single.replace(pattern, (fm, thePrefix, name, poss, suffix, noun) => {
            const { modifier: fixedModifier } = findCompoundModifier(subject.compounds, noun);
            if (!fixedModifier) return fm;
            const cap = titleCase ? fixedModifier.charAt(0).toUpperCase() + fixedModifier.slice(1) : fixedModifier.toLowerCase();
            const the = thePrefix ? thePrefix : (titleCase ? 'The ' : 'the ');
            return `${the}${cap} ${name}${poss || ''}${suffix}`;
          });
          if (newVal !== single) {
            if (dbg) console.log('[Contextualizer] fixCompoundsEverywhere MODIFIED node (marking WHOLE node processed):', JSON.stringify(single.slice(0,100)), '->', JSON.stringify(newVal.slice(0,100)));
            node.nodeValue = newVal; compoundProcessed.add(el); processedTextNodes.add(node);
          }
          continue;
        }

        if (i + 1 < textNodes.length) {
          const next = textNodes[i + 1];
          const combined = single + next.nodeValue;
          if (pattern.test(combined)) {
            pattern.lastIndex = 0;
            const newCombined = combined.replace(pattern, (fm, thePrefix, name, poss, suffix, noun) => {
              const { modifier: fixedModifier } = findCompoundModifier(subject.compounds, noun);
              if (!fixedModifier) return fm;
              const cap = titleCase ? fixedModifier.charAt(0).toUpperCase() + fixedModifier.slice(1) : fixedModifier.toLowerCase();
              const the = thePrefix ? thePrefix : (titleCase ? 'The ' : 'the ');
              return `${the}${cap} ${name}${poss || ''}${suffix}`;
            });
            if (newCombined !== combined) {
              node.nodeValue = newCombined;
              next.nodeValue = '';
              compoundProcessed.add(el);
              processedTextNodes.add(node);
              processedTextNodes.add(next);
            }
          }
        }
      }
    });
  });
}

// =============================================================================
// Site-specific Easter Eggs
// =============================================================================

// Washington Post tagline swap — only fires on washingtonpost.com
function replaceWaPoTagline(root) {
  if (!/(^|\.)washingtonpost\.com$/.test(location.hostname)) return;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
  let n;
  const nodes = [];
  while ((n = walker.nextNode())) nodes.push(n);
  nodes.forEach(node => {
    if (/Democracy Dies in Darkness/i.test(node.nodeValue)) {
      node.nodeValue = node.nodeValue.replace(/Democracy Dies in Darkness/gi, 'Democracy Dies in the Hands of Billionaires');
    }
  });
}

// Some site card containers bundle the headline and blurb/summary text under one shared
// wrapper (see walkTextNodes' acceptNode). This walker filter mirrors that exclusion so the
// "mark as processed" passes below don't swallow blurb text nodes before the normal pass runs.
function nonBlurbTextWalker(root) {
  return document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      const parent = node.parentElement;
      if (parent && parent.closest('[data-tpl="bo"]')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  });
}

// --- Remote kill-switch / domain blocklist -----------------------------------------------
// This extension is sideloaded (not distributed via the Chrome Web Store), so there is no
// auto-update mechanism -- whatever version someone installs is the version they keep running
// indefinitely, until/unless they manually reinstall. A hardcoded exclude list baked into the
// code would therefore only ever protect *future* installs, not anyone already running it.
//
// Instead, fetch a small hosted list of blocked hostnames at the start of every run. If a
// domain is ever added to that list, every already-installed copy respects it on its very next
// page load -- no reinstall required from anyone. If the fetch fails, times out, or the file is
// simply empty/missing, this fails OPEN: the extension runs exactly as if this feature didn't
// exist. It should never be able to break or meaningfully delay normal operation.
const CTX_BLOCKLIST_URL = 'https://gist.githubusercontent.com/Mch7777/b7aa683412ee50d31441bdccfd67b658/raw/gistfile1.txt';
const CTX_BLOCKLIST_TIMEOUT_MS = 1200;

function ctxHostIsBlocked(list) {
  const host = location.hostname.replace(/^www\./, '').toLowerCase();
  return list.some(entry => {
    const e = entry.trim().toLowerCase();
    if (!e || e.startsWith('#')) return false;
    return host === e || host.endsWith('.' + e);
  });
}

function ctxFetchBlocklist() {
  return new Promise((resolve) => {
    let settled = false;
    const settle = (list) => { if (!settled) { settled = true; resolve(list); } };
    setTimeout(() => settle([]), CTX_BLOCKLIST_TIMEOUT_MS);
    fetch(CTX_BLOCKLIST_URL, { cache: 'no-store' })
      .then(r => (r.ok ? r.text() : ''))
      .then(text => settle(text.split('\n').filter(Boolean)))
      .catch(() => settle([]));
  });
}

// Run compound pass everywhere, regular pass nav-excluded, innerHTML pass for split nodes
function ctxInit() {
fixCompoundsEverywhere(document.body);
replaceWaPoTagline(document.body);
// Walk headings first so article headlines get first mention before body text
const headings = document.body.querySelectorAll('h1, h2, h3, h4, h5, h6, [data-testid="headline"], [data-tpl="h"], [data-tpl="f"], [data-tpl="sli"], [data-tpl="slic"], .indicate-hover, [data-editable="headline"], [data-testid="main-collection"] li p:first-child');
if (CTX_DEBUG && window === window.top) console.log('[Contextualizer] found', headings.length, 'headings on initial pass (top frame)');
// Some sites (NYT among them) mark an article's dek/subhead as a genuine semantic heading
// (e.g. <h2>) sitting directly under the <h1>. Treating every heading as an independent
// "always keep the name" headline is deliberately generous — it's needed so genuinely separate
// headlines elsewhere on a page (an unrelated teaser in a sidebar, a different story on a
// section front) each correctly get their own first mention rather than losing the name just
// because some earlier headline already introduced the subject. But that generosity over-fires
// on a dek: it's not a separate headline, it's part of the same headline unit as the <h1>
// immediately above it, and should inherit whatever introduced-state that unit already has —
// same as ordinary body text would.
//
// Two signals, either one sufficient: (1) DOM order — it's the very first non-h1 heading
// encountered since the last h1, with nothing else matched in between. This is the primary,
// robust signal: it doesn't depend on nesting depth at all, just on the (very standard) web
// convention that main content appears in DOM order before sidebars/related-content sections.
// (2) DOM proximity — shares a very close common ancestor with the most recent h1 (tight
// 3-level cap). This is a supplementary tie-breaker only, not a primary signal on its own:
// testing against realistic page structures showed that any generous-enough depth threshold to
// catch a genuinely deep dek will also, for unrelated reasons, occasionally walk all the way up
// to <body> for some other, shallower element — and <body> trivially "contains" everything on
// the page, causing false positives. A tight cap avoids that failure mode while still catching
// the common case of a dek sitting as a near-sibling of its h1's own container.
function ctxIsDekOfHeading(candidate, h1) {
  if (!h1) return false;
  let ancestor = candidate.parentElement;
  for (let i = 0; i < 3; i++) {
    if (!ancestor) return false;
    if (ancestor.contains(h1)) return true;
    ancestor = ancestor.parentElement;
  }
  return false;
}

// Persistent (not per-call) so a later remount of just the dek, without its h1 also being
// re-added, can still fall back on the ancestor-proximity signal against the h1 we already know
// about. ctxSeenNonH1SinceLastH1 only resets when a new h1 arrives, same as before.
let ctxLastH1 = null;
let ctxSeenNonH1SinceLastH1 = false;

// Shared by both the one-time initial page-load pass below AND the MutationObserver's
// newly-added-heading handling further down. Originally, only the initial pass ran this
// dek-detection logic at all -- when React remounts a whole block (a new h1 AND its dek arriving
// together as fresh DOM nodes, confirmed via debug log: the remounted pair got reprocessed with
// isHeadline hardcoded to true, undoing the correct dek-suppression from moments earlier), that
// second code path had no dek-detection of its own and treated every new heading as an
// independent headline unconditionally. Extracting this into one function both paths call keeps
// them in sync instead of silently drifting apart.
function ctxProcessHeadings(headingsList) {
  headingsList.forEach(h => {
    let treatAsHeadline = true;
    if (h.tagName === 'H1') {
      ctxLastH1 = h;
      ctxSeenNonH1SinceLastH1 = false;
    } else {
      // Collection/topic-page teasers (matched via the data-testid="main-collection" selector
      // above) are always independent stories by construction, never a dek of some other h1 on
      // the page — exempt them from dek-detection entirely rather than let the order-based
      // signal (which can't otherwise tell "genuine dek" apart from "coincidentally first
      // teaser in a topic listing") suppress the very first one.
      // Narrower than just "inside a main-collection section" — that container turned out to
      // wrap the entire topic page (including the page's own h1 and its dek, sitting in a
      // <header> above the actual story list), not just the teaser list itself. Requiring the
      // heading to also be inside a real <li> matches the exact same specificity as the original
      // selector that finds these teasers in the first place.
      const isCollectionTeaser = !!h.closest('[data-testid="main-collection"] li');
      if (!isCollectionTeaser) {
        const isFirstSinceH1 = ctxLastH1 && !ctxSeenNonH1SinceLastH1;
        if (isFirstSinceH1 || ctxIsDekOfHeading(h, ctxLastH1)) {
          treatAsHeadline = false;
        }
      }
      ctxSeenNonH1SinceLastH1 = true;
    }
    if (CTX_DEBUG) console.log('[Contextualizer] processing heading:', h.tagName, 'treatAsHeadline:', treatAsHeadline, JSON.stringify(h.textContent.slice(0, 60)));
    walkTextNodes(h, false, treatAsHeadline);
  });
}

ctxProcessHeadings(headings);
// Mark all heading text nodes as processed so the full-body walk below doesn't reprocess them
// (blurb/summary text nodes are excluded here so they still fall through to the normal pass)
headings.forEach(h => {
  const walker = nonBlurbTextWalker(h);
  let n;
  while ((n = walker.nextNode())) processedTextNodes.add(n);
});
walkTextNodes(document.body, true);
walkTextNodes(document.body, false);
walkElementsForHTML(document.body);

// --- SPA navigation handling -------------------------------------------------------------
// Single-page apps (Gmail, and any other JS-routed site) swap content in-place without a full
// page reload, so content.js only ever runs once per tab. subjectState.introduced is a plain
// flag with no per-node lifetime — once set true, it stays true for the rest of the tab's life,
// even after the user navigates to a completely different message/article. That caused a real
// bug: opening a second Trump-related email after an earlier one in the same Gmail tab had its
// own headline mention treated as "subsequent" and lost the name entirely (e.g. "the hideous
// man's" instead of "the hideous man Trump's"), even though it was the first — and only —
// mention the reader actually saw for that message.
//
// Detect SPA navigation via the History API and hash changes, and reset introduced-state so the
// next mention on the new "page" is treated as fresh again. Content already processed before the
// reset is untouched — this only affects mentions inserted afterward. Also clears recentHistory
// (the modifier-repeat-avoidance buffer) for the same reason: a genuinely new "view" -- a new
// email, a new client-side-routed article -- should get its own fresh sense of "what's already
// been used," not inherit exhaustion from whatever page was open before it in the same tab.
// recentHistory is a Map keyed by array reference, so one .clear() covers the main modifier pool,
// every compound's own modifier pool, and adjectiveNouns all at once.
function resetIntroducedState() {
  subjectState.forEach(s => { s.introduced = false; });
  recentHistory.clear();
  if (CTX_DEBUG) console.log('[Contextualizer] SPA navigation detected — reset introduced state');
}

let lastCtxUrl = location.href;
function checkCtxUrlChange() {
  if (location.href !== lastCtxUrl) {
    lastCtxUrl = location.href;
    resetIntroducedState();
  }
}

['pushState', 'replaceState'].forEach(fnName => {
  const orig = history[fnName];
  history[fnName] = function (...args) {
    const result = orig.apply(this, args);
    checkCtxUrlChange();
    return result;
  };
});
window.addEventListener('popstate', checkCtxUrlChange);
window.addEventListener('hashchange', checkCtxUrlChange);

const observer = new MutationObserver((mutations) => {
  for (const mutation of mutations) {
    // Some sites (e.g. a Fox News personalization/tracking widget we found) update card content
    // by directly overwriting an EXISTING text node's .data/.nodeValue in place, rather than
    // removing and inserting new nodes. childList observation alone is blind to this — the text
    // silently reverts to unprocessed content with no childList mutation ever firing. Watch
    // characterData too, and explicitly un-mark the node from processedTextNodes since its
    // content has genuinely changed underneath us (the WeakSet guard would otherwise permanently
    // block reprocessing here). alreadyModified/alreadyContextualized still protect against
    // reprocessing our own prior output as if it were fresh.
    if (mutation.type === 'characterData') {
      const node = mutation.target;
      const parent = node.parentElement;
      const isTextHeadline = !!(parent && parent.closest && parent.closest('h1, h2, h3, h4, h5, h6, [data-testid="headline"], [data-tpl="h"], [data-tpl="f"], [data-tpl="sli"], [data-tpl="slic"], .indicate-hover, [data-editable="headline"]'));
      if (CTX_DEBUG && /Trump/.test(node.nodeValue || '')) console.log('[Contextualizer] characterData mutation caught, isHeadline:', isTextHeadline, JSON.stringify((node.nodeValue||'').slice(0,60)));
      processedTextNodes.delete(node);
      processCompoundNode(node);
      processTextNode(node, isTextHeadline);
      continue;
    }
    for (const added of mutation.addedNodes) {
      if (added.nodeType === Node.TEXT_NODE) {
        // Previously always passed isHeadline=undefined here, regardless of context — meaning
        // any headline whose text streamed in as a bare text-node insertion (text filled into an
        // already-existing empty heading element, rather than the element itself being inserted)
        // permanently lost headline treatment. Check the actual parent element instead.
        const textParent = added.parentElement;
        const isTextHeadline = !!(textParent && textParent.closest && textParent.closest('h1, h2, h3, h4, h5, h6, [data-testid="headline"], [data-tpl="h"], [data-tpl="f"], [data-tpl="sli"], [data-tpl="slic"], .indicate-hover, [data-editable="headline"]'));
        processCompoundNode(added);
        processTextNode(added, isTextHeadline);
      } else if (added.nodeType === Node.ELEMENT_NODE) {
        fixCompoundsEverywhere(added);
        replaceWaPoTagline(added);
        // Process any new headline elements (or the added node itself if it's a headline) first.
        // Selector kept identical to the initial pass's `headings` query above (including the
        // collection/topic-page clause) so a remounted teaser is recognized the same way here.
        const newHeadings = added.matches && added.matches('h1, h2, h3, h4, h5, h6, [data-testid="headline"], [data-tpl="h"], [data-tpl="f"], [data-tpl="sli"], [data-tpl="slic"], .indicate-hover, [data-editable="headline"], [data-testid="main-collection"] li p:first-child')
          ? [added]
          : Array.from(added.querySelectorAll ? added.querySelectorAll('h1, h2, h3, h4, h5, h6, [data-testid="headline"], [data-tpl="h"], [data-tpl="f"], [data-tpl="sli"], [data-tpl="slic"], .indicate-hover, [data-editable="headline"], [data-testid="main-collection"] li p:first-child') : []);
        // Was: newHeadings.forEach(h => walkTextNodes(h, false, true)) -- hardcoded isHeadline=true
        // for every newly-added heading, unconditionally. That's what let a remounted h1+dek pair
        // (confirmed via debug log) undo the correct dek-suppression computed moments earlier:
        // this path had no dek-detection of its own at all. Now routes through the same shared
        // logic the initial pass uses.
        ctxProcessHeadings(newHeadings);
        // Mark heading text nodes as processed so the general walk below doesn't reprocess them
        // (blurb/summary text nodes are excluded here so they still fall through to the normal pass)
        newHeadings.forEach(h => {
          const hw = nonBlurbTextWalker(h);
          let hn;
          while ((hn = hw.nextNode())) processedTextNodes.add(hn);
        });
        walkTextNodes(added, true);
        walkTextNodes(added, false);
        walkElementsForHTML(added);
      }
    }
  }
});

observer.observe(document.body, { childList: true, subtree: true, characterData: true });

} // end ctxInit()

ctxFetchBlocklist().then((list) => {
  if (ctxHostIsBlocked(list)) {
    if (CTX_DEBUG) console.log('[Contextualizer] this site is on the remote blocklist — standing down.');
    return;
  }
  ctxInit();
});
